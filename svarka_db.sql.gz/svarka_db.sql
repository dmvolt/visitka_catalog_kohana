-- phpMyAdmin SQL Dump
-- version 4.0.10.10
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 03 2017 г., 19:58
-- Версия сервера: 5.5.45
-- Версия PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `svarka_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `start_time` int(32) DEFAULT NULL,
  `end_time` int(32) DEFAULT NULL,
  `start_date` varchar(64) DEFAULT NULL,
  `end_date` varchar(64) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `start_time`, `end_time`, `start_date`, `end_date`, `alias`, `weight`, `status`) VALUES
(6, NULL, NULL, NULL, NULL, 'vesennyaya-rasprodazha-elektrodov', 0, 1),
(7, NULL, NULL, NULL, NULL, 'skidka-20-na-ves-assortiment-k-dnyu-stroitelya', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `appointments`
--

CREATE TABLE IF NOT EXISTS `appointments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `category_id` int(5) DEFAULT NULL,
  `doctor_id` int(3) DEFAULT NULL,
  `date` varchar(64) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `contact` varchar(128) DEFAULT NULL,
  `time` varchar(128) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` varchar(32) NOT NULL,
  `author` varchar(100) DEFAULT NULL,
  `alias` varchar(250) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `is_fine` int(1) NOT NULL DEFAULT '0',
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=80 ;

-- --------------------------------------------------------

--
-- Структура таблицы `banners`
--

CREATE TABLE IF NOT EXISTS `banners` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) DEFAULT NULL,
  `code` text,
  `display_pages` text,
  `display_all` int(1) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `banners`
--

INSERT INTO `banners` (`id`, `title`, `code`, `display_pages`, `display_all`, `status`) VALUES
(7, 'Баннер в верхней части сайта', NULL, '', 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `butiks`
--

CREATE TABLE IF NOT EXISTS `butiks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `address` varchar(250) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `alias` varchar(250) DEFAULT NULL,
  `site` varchar(250) DEFAULT NULL,
  `pos_x` int(5) DEFAULT NULL,
  `pos_y` int(5) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Структура таблицы `butiks_actions`
--

CREATE TABLE IF NOT EXISTS `butiks_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `butik_id` int(11) DEFAULT NULL,
  `action_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--

CREATE TABLE IF NOT EXISTS `catalog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `price1` varchar(250) DEFAULT NULL,
  `price2` varchar(250) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `is_fine` int(1) NOT NULL DEFAULT '0',
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=87 ;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id`, `price1`, `price2`, `alias`, `is_fine`, `weight`, `status`) VALUES
(86, '5000', NULL, 'maska-zaschitnaya', 0, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parent_id` int(5) NOT NULL,
  `alias` varchar(64) CHARACTER SET utf8 NOT NULL,
  `dictionary_id` int(5) NOT NULL DEFAULT '0',
  `weight` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=240 ;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `alias`, `dictionary_id`, `weight`) VALUES
(232, 0, 'svarochnoe-oborudovanie', 1, 0),
(233, 0, 'gazosvarochnoe-oborudovanie', 1, 0),
(234, 0, 'abrazivy-i-instrumenty', 1, 0),
(235, 0, 'svarochnye-materialy', 1, 0),
(236, 0, 'sredstva-zaschity-i-aksessuary', 1, 0),
(237, 0, 'vspomogatelnye-materialy', 1, 0),
(238, 236, 'maski', 1, 0),
(239, 238, 'polnorazmernye', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `contents_categories`
--

CREATE TABLE IF NOT EXISTS `contents_categories` (
  `category_id` int(5) NOT NULL,
  `content_id` int(5) NOT NULL,
  `module` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contents_categories`
--

INSERT INTO `contents_categories` (`category_id`, `content_id`, `module`) VALUES
(158, 23, 'services'),
(158, 15, 'services'),
(159, 22, 'services'),
(159, 21, 'services'),
(157, 7, 'services'),
(158, 24, 'services'),
(157, 8, 'services'),
(157, 9, 'services'),
(157, 10, 'services'),
(160, 11, 'services'),
(158, 12, 'services'),
(158, 13, 'services'),
(162, 19, 'services'),
(161, 20, 'services'),
(158, 16, 'services'),
(161, 17, 'services'),
(161, 18, 'services'),
(236, 86, 'catalog'),
(238, 86, 'catalog'),
(239, 86, 'catalog');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_descriptions`
--

CREATE TABLE IF NOT EXISTS `contents_descriptions` (
  `content_id` int(10) NOT NULL,
  `lang_id` int(3) NOT NULL,
  `content_title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `content_teaser` text CHARACTER SET utf8 NOT NULL,
  `content_body` text CHARACTER SET utf8 NOT NULL,
  `content_menu` varchar(255) CHARACTER SET utf8 NOT NULL,
  `content_var_field1` varchar(255) CHARACTER SET utf8 NOT NULL,
  `content_var_field2` varchar(255) CHARACTER SET utf8 NOT NULL,
  `content_text_field` text CHARACTER SET utf8 NOT NULL,
  `module` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `contents_descriptions`
--

INSERT INTO `contents_descriptions` (`content_id`, `lang_id`, `content_title`, `content_teaser`, `content_body`, `content_menu`, `content_var_field1`, `content_var_field2`, `content_text_field`, `module`) VALUES
(3, 1, 'Контакты', '', '<p>\n	Контактные данные\n</p>\n<p>\n	 <span style="background-color: initial;"></span>\n</p>', '', '', '', '', 'pages'),
(3, 2, 'Contacts', '', '<table><tbody><tr> <td style="text-align: center;">\n  <img src="/files/1412319639_screenshot9.png">\n </td> <td style="text-align: center;">\n  <p>\n   <img src="/files/1412756011_screenshot11.png">\n  </p>\n </td> <td style="text-align: center;">\n  <img src="/files/1412755960_screenshot12.png"> \n\n </td></tr><tr> <td>\n  <strong> Warehouse </strong> \n\n         Novosibirsk, Avtogennaya St. 126k1\n </td> <td>\n  <strong> Office </strong> <strong> </strong> \n\n    Novosibirsk, st. of Kirov, 86\n </td> <td>\n  <strong> Production case </strong> \n\n    Novosibirsk region,\n  \n\n    settlement. Lake Karachi, Lesnaya St., 1\n </td></tr><tr> <td>\n  \n\n </td> <td>\n </td> <td>\n </td></tr></tbody></table><p>\n <strong> Department of regional sales: </strong>\n</p><p>\n <strong> </strong> the Head - Popkov Dmitry Yuryevich Email: <u> <href ="mailto:d="" .popkov@minwater.net"=""> d.popkov@minwater.net  </href></u>\n</p><p>\n <u> <a href="mailto:d .popkov@minwater.net"> </a> </u> the Area manager - Teeth Sergey Gennadevich Email: <u> <href ="mailto:zubov@minwater.net="" "="">zubov@minwater.net  </href></u>\n</p><p>\n <u> </u> the Area manager - Lemzyakova Anna Aleksandrovna Email: <u> <href ="mailto:a="" .lem@minwater.net"=""> a.lem@minwater.net  </href></u>\n</p><p>\n <u> </u> Email: <u> <href ="mailto:info@minwater.net="" "="">info@minwater.net  </href></u> Address: 630102, Novosibirsk, st. of Kirov, 86\n</p><p>\n  Phone: +7 (383) 266-03-45, +7 (383) 264-31-51\n</p><p>\n  Fax: +7 (383) 266-13-10\n</p><p>\n <strong> Department of regional development: </strong>\n</p><p>\n <strong> </strong> the Head - Musikhin Vladislav Aleksandrovich of Ph. 8-913-985-63-60, Email: <u> <href ="mailto:musihin@minwater.net="" "="">musihin@minwater.net  </href></u>\n</p><p>\n <u> <a href="mailto:musihin@minwater.net"> </a> </u> the Area manager - Runners Konstantin Petrovich of Ph. 8-923-502-16-70 Email: <href ="mailto:k="" .begunov@minwater.net"=""> k.begunov@minwater.net  \n\n  Representation in Kazakhstan: Rodnik KR LLP\n</href></p><p>\n <strong> Sales department for Novosibirsk: </strong>\n</p><p>\n <strong> </strong> Amelchuk Valentina Vladimirovna Email: <href ="mailto:v="" .amelchuk@minwater.net"=""> v.amelchuk@minwater.net  \n\n  Address: Avtogennaya St., 126 \n \n\n  Phone: +7 (383) 267-17-92\n</href></p><p>\n <strong> Department of marketing and advertizing: </strong>\n</p><p>\n <strong> </strong> Talanina Oksana Petrovna Email: <u> <href ="mailto:o="" .talanina@minwater.net"=""> o.talanina@minwater.net  </href></u>\n</p><p>\n <u> <href ="mailto:o="" .talanina@minwater.net"="">  </href></u> Voronkina Tatyana Anatolyevna Email: <href ="mailto:voronkina@minwater.net="" "="">voronkina@minwater.net \n</href></p><p>\n <u style="background-color: initial;"> Phone: +7 (383) 266-13-10 </u>\n</p><p>Virtual round on plant</p>', '', '', '', '', 'pages'),
(3, 3, '', '', '', '', '', '', '', 'pages'),
(1, 1, 'СибТрейд', '<p>\r\n	        г. Новосибирск, ул. Уральская 20.\r\n</p>', '', '', 'Компания СибТрейд', '© Компания СибТрейд', '', 'siteinfo'),
(1, 2, '', '', '<p>\r\n	<br /></p>', '', '', '', '', 'siteinfo'),
(1, 3, '', '', '', '', '', '', '', 'siteinfo'),
(1, 4, '', '', '', '', '', '', '', 'siteinfo'),
(2, 4, '', '', '', '', '', '', '', 'menu'),
(2, 1, 'Прайс-лист', '', '', '', '', '', '', 'menu'),
(2, 2, 'About', '', '', '', '', '', '', 'menu'),
(2, 3, 'نبذة عن الشركة', '', '', '', '', '', '', 'menu'),
(8, 1, 'Монтаж окон', '<p>Описание этапов монтажа пластиковых оконных конструкций.</p>\n', '<h1>Монтаж пластиковых окон</h1>\n\n<div>У ваших соседей провисают створки окон? Знакомые жалуются на конденсат? Монтаж нужно было заказывать у нас! Мы производим монтаж пластиковых окон в Новосибирске в несколько этапов:</div>\n\n<ul>\n	<li>Замер оконных проемов;</li>\n	<li>Оценка и коррекция оконного проёма;</li>\n	<li>Демонтаж старых оконных рам;</li>\n	<li>Очистка проема, при необходимости &ndash; герметизация;</li>\n	<li>Установка новых рам и стеклопакетов;</li>\n	<li>Герметизация (первичный и вторичный герметик);</li>\n	<li><a href="/services/otdelka-plastikovyh-okon">Отделка: установка откосов, наружных уголков, слива</a>;</li>\n	<li>Установка подоконника;</li>\n	<li>Регулировка фурнитуры;</li>\n</ul>\n\n<div>После того, как опытными специалистами будет завершена установка пластиковых окон, ваши новые окна защищаются нашими гарантийными условиями. И это ещё одна веская причина, чтобы обратиться к нам уже сегодня!</div>\n\n<h2>Стоимость установки пластиковых окон</h2>\n\n<div>\n<table border="0" cellpadding="10" cellspacing="1">\n	<tbody>\n		<tr>\n			<td colspan="3">Оказывается, каждый может значительно сократить статью расходов при замене окон. Чтобы знать, как сэкономить, изучите решения компании &laquo;Элитмонтаж&raquo;.</td>\n		</tr>\n		<tr>\n			<td>\n			<div class="mark">Обращайтесь к производителю окон, а не к посредникам. Тогда стоимость пластикового окна с установкой будет для вас значительно ниже.</div>\n\n			<p>&nbsp;</p>\n\n			<p>Например, стоимость пластиковых окон, включая их монтаж, начинаются от 9850 рублей. А&nbsp;<a href="/services/osteklenie-balkonov-i-lodzhiy" target="_blank">остекление балкона</a>&nbsp;будет вам доступно за сумму от 15 000 рублей. Узнав, сколько стоит установка пластиковых окон в Новосибирске на странице&nbsp;<a href="/services/razmery-ceny-plastikovye-okna/" target="_blank">Размеры и цены на пластиковые окна</a>, вы увидите, что это одни из самых низких цен на рынке за качественные окна.</p>\n			</td>\n			<td>&nbsp;</td>\n			<td>\n			<p>Требуйте полный комплекс услуг без доплаты!</p>\n\n			<p>Вы можете озвучить оптимальный для вас бюджет, чтобы менеджер пластиковых окон предложил вам лучшее решение.</p>\n\n			<div class="mark-green">\n			<p>У нас вы можете выбрать не только материал, цвет профиля, но и материалы для отделки откосов. Так мы помогаем клиентам не выйти за рамки бюджета &mdash; никаких лишних трат, никаких дополнительных платежей после расчёта суммы заказа!</p>\n			</div>\n			</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n</div>\n\n<div class="mark">Узнайте про гарантию. Например, специалисты компании &laquo;Элитмонтаж&raquo; предлагают бесплатную <a href="/services/remont-i-regulirovka-plastikovyh-okon"><span style="color:#FFFFFF;">замену фурнитуры и ремонт окон</span></a> в течение гарантийного срока.</div>\n\n<p>Но что делать, если гарантийный срок вышел, а вы случайно повредили окно? Чтобы не тратиться на полную замену окна, вам нужен надёжный сервис. Наши специалисты готовы обслуживать клиентов на постоянной основе. Вам нужно только позвонить менеджеру, чтобы мы помогли вам с ремонтом в кратчайшие сроки.</p>\n\n<p>Позвоните нашим менеджерам, чтобы <a href="/">купить пластиковое окно</a> по самым выгодным ценам прямо сейчас!</p>\n<script type="text/javascript" src="//yandex.st/share/share.js"\ncharset="utf-8"></script>\n\n<div class="yashare-auto-init" data-yasharel10n="ru" data-yasharequickservices="vkontakte,facebook,twitter,odnoklassniki,moimir" data-yasharetype="none">&nbsp;</div>\n', '', '', '', '', 'services'),
(3, 4, '', '', '', '', '', '', '', 'pages'),
(15, 1, 'Отделка балконов', '<p>Отделка и обшивка балконов и лоджий - варианты материалов и способы отделки.&nbsp;</p>\n', '<h1>Отделка и обшивка балконов и лоджий&nbsp;</h1>\n\n<p>Сейчас многие квартиры сдаются с уже застекленными лоджиями, но их отделка присутствует не всегда. Что делать, если вы стали обладателем такой квартиры? Как придать балкону или лоджии законченный вид? Не все <a href="/">фирмы по установке пластиковых окон в Новосибирске</a> смогут вам помочь, но компании &laquo;Элитмонтаж&raquo; готова предложить вам свои услуги.</p>\n\n<table cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/vnutrennyaya-otdelka-lodzhii1.jpg" style="font-size: 12px; line-height: 16px; width: 120px; height: 160px;" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/vnutrennyaya-otdelka-lodzhii2.jpg" style="font-size: 12px; line-height: 16px; width: 120px; height: 150px;" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/vnutrennyaya-otdelka-balkona.jpg" style="width: 120px; height: 120px;" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/vnutrennyaya-otdelka-lodzhii.jpg" style="font-size: 12px; line-height: 16px; width: 120px; height: 90px;" /></td>\n		</tr>\n	</tbody>\n</table>\n\n<div class="accordion">\n<h2>Внутренняя отделка балконов и лоджий в Новосибирске</h2>\n\n<div>\n<p>Первым делом мы выбираем отделочные материалы, подходящие под ваши задачи. Отделка внутри вспомогательного помещения требует особого подхода. Важно, чтобы при перепадах температур и при высокой влажности отделочные материалы прослужили как можно дольше.</p>\n\n<h3>Защита от холода:</h3>\n\n<p>Для того чтобы на балконе и лоджии сохранялось тепло, мы используем специальные изоляционные материалы. Они укладываются на пол, стены и потолок, и надежно защищают помещение от холода.</p>\n\n<h3>Обшивка:</h3>\n\n<p>Мы используем все доступные материалы от самых экономичных до элитных. Вы сами выбираете, чем обшить стены, чтобы отделка вписалась в ваш интерьер.</p>\n\n<h3>Нужны натуральные материалы для отделки?</h3>\n\n<p>Если вам важно обшить балкон или лоджию экологически чистым материалом, то лучше всего подойдёт дерево. <a href="/services/evrovagonka">Отделка балкона евровагонкой</a> &ndash; самый популярный вариант обшивки стен и потолка. Если для вашего проекта нужен именно этот материал, мы дополнительно защитим его от влаги с помощью лакосодержащей пропитки.</p>\n\n<h3>Планируете сэкономить</h3>\n\n<p>В некоторых случаях необходимо подобрать наиболее экономичный материал, а его внешний вид играет второстепенную роль. Тогда на помощь придут недорогие материалы для внутренней отделки балконов и лоджий. Мы можем предложить вариант с высокой устойчивостью к влаге и перепадом температур. Это <a href="/services/plastikovye-stenovye-paneli">стеновые пластиковые панели</a>. Их преимущество не только в высокой надёжности и длительным сроком службы. Важно и то, что вы сможете выбрать практически любой нужный оттенок.&nbsp;</p>\n\n<h3>Чем обшить лоджию внутри, не нарушая общий интерьер?</h3>\n\n<p>Если для вас важно, чтобы дизайн балкона гармонично сочетался с отделкой внутреннего помещения, рассмотрите вариант с использованием гипсокартона или штукатурки. Потом стены можно покрасить в нужный цвет, оклеить обоями или плиткой. При выборе любого материала наши специалисты помогут рассчитать оптимальную стоимость внутренней отделки балкона или лоджии.</p>\n\n<p>Чтобы вы могли наглядно представить себе результат нашей работы, посмотрите примеры <a href="/services/otdelka-obshivka-balkonov">отделки балкона в хрущёвке</a> и полногабаритной квартире в нашей фотогалерее. При совершенно разных исходных данных наши клиенты получили одинаково потрясающий результат!</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Наружная отделка балконов и лоджий в Новосибирске</h2>\n\n<div>\n<p>Чтобы придать балкону законченный вид и дополнительно защитить от шума, пыли, влаги и мороза, требуется качественная внешняя отделка. Прежде всего, материалы должны выдерживать как суровую зиму, так и жаркое лето, соответственно <a href="/services/otdelka-obshivka-balkonov">обшивка балконов и лоджий</a> требует серьезного подхода и наличия у отделочников немалого опыта. С уличной стороны же еще всем видно, как они выглядят, поэтому материалы для облицовки лоджии должны быть ещё и эстетичными, чтобы органично вписаться в общий вид фасада.&nbsp;</p>\n\n<p>Для внешней отделки мы используем профнастил. Он доступен по цене, долговечен, устойчив к выгоранию. Важно, чтобы <a href="/services/montazh-saydinga-novosibirsk">монтаж сайдинга</a> выполнялся со строгим соблюдением технологии. Чтобы обшить балкон снаружи подходящим материалом, мы изучаем особенности здания и учитываем ваши пожелания.&nbsp;</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Стоимость обшивки лоджии&nbsp;</h2>\n\n<div>\n<p>В любом случае, мы гарантируем, что затраты на завершение ремонта будут невелики. Мы заботимся о том, чтобы цены на отделку балконов и лоджий под ключ были действительно выгодными для наших клиентов.&nbsp;</p>\n\n<h3>Если вам нужно обшить балкон:</h3>\n\n<p>Балкон традиционно меньше, чем лоджия. Обычно здесь делают не дополнительное тёплое помещение, а место для хранения. И хотя цены на обшивку балконов во многом зависят от состояния пола и стен, в большинстве случаев они невысоки.&nbsp;</p>\n\n<h3>Если вам нужно обшить лоджию:</h3>\n\n<p>Здесь площадь позволяет экспериментировать с пространством и воплощать в жизнь различные идеи. Несмотря на то, что работы в этом случае обычно сложнее, а материалов требуется больше, цены обшивки лоджии у нас одни из самых низких в городе. Какая бы задача не стояла перед вами, мы поможем добиться нужного результата и сэкономить.</p>\n</div>\n</div>\n\n<p>Позвоните нам, и мы ответим на все ваши вопросы!&nbsp;</p>\n', '', '', '', '', 'services'),
(90, 1, 'Амурского государственного университета', '<p>С 18 по 20 мая на базе Амурского государственного университета соберутся порядка 700 магистрантов и аспирантов, а также молодых ученых и специалистов со всей России. Всех их объединит «Космофест Восточный» – образовательное пространство, где созданы все условия для формирования молодежных профессиональных сообществ в ракетно-космической отрасли.</p>', '<p>С 18 по 20 мая на базе Амурского государственного университета соберутся порядка 700 магистрантов и аспирантов, а также молодых ученых и специалистов со всей России. Всех их объединит «Космофест Восточный» – образовательное пространство, где созданы все условия для формирования молодежных профессиональных сообществ в ракетно-космической отрасли.</p><p>Программа «Космофеста» предполагает мастер-классы по ракетомоделированию и спутникостроению, организации поисково-спасательной службы в пилотируемой космонавтике и системам обеспечения жизнедеятельности космонавтов, профориентационная площадка «Карьерная траектория» и многое другое.</p><p>В рамках панельной дискуссии о развитии ракетно-космической отрасли России с участием экспертов и приглашенных гостей пройдет также молодежная сессия, которая затронет актуальные вопросы о перспективных направлениях развития отечественной космонавтики в Дальневосточном федеральном округе. Состоится встреча проектной группы «Комплексное развитие космического кластера на Востоке России».</p><p>Предполагается работа лектория «Открытый космос»: лекции и выступления космонавтов, представителей космической отрасли, научной сферы и работа космического киноклуба, финальная битва «Юных прогрессоров».</p><p>На фестивале также будет работать выставка инновационных проектов студентов вузов в области космических технологий.</p>', '', '', '', '', 'news'),
(16, 1, '', '', '', '', '', '', '', 'modulinfo'),
(17, 1, '', '', '', '', '', '', '', 'modulinfo'),
(15, 1, 'О нас', '', '<h1><span style="font-size: 24px;">Наша компания на строительном рынке более 15 лет.</span></h1>\n<p style="margin-left: 20px;">\n</p>\n<p>\n	Информация о компании\n</p>\n<h1>\n<p style="margin-left: 20px;">\n	 <span style="font-size: 16px;"><span style="font-weight: normal;"></span></span>\n</p>\n<p>\n	 <span style="font-size: 18px; font-weight: normal;"></span>\n</p>\n</h1>\n<p style="margin-left: 280px;">\n</p>\n<p style="margin-left: 200px;">\n</p>', '', '', '', '', 'pages'),
(7, 1, 'Цены на окна', '<p>Цены на стандартные окна, прайс-лист, принципы формирования стоимости оконных конструкций<span id="cke_bm_305E" style="display: none;"> </span>.</p>\n', '<h1>Размеры и цены на пластиковые окна</h1>\n\n<p>Прежде чем приступить к замене окон, мы рекомендуем тщательно спланировать бюджет. Поэтому важно, чтобы вы хорошо представляли <strong>цены на пластиковые окна в Новосибирске и Бердске</strong>. Мы предлагаем рассмотреть две ценовые категории окон: стандартные и требующие индивидуального подхода.</p>\n\n<h2><a id="priceokno" name="priceokno"></a>Окна по стандартным размерам</h2>\n\n<p>Для большинства наших клиентов подойдёт именно этот вариант, потому что в большинстве домов типовые размеры оконных проёмов. О том, сколько стоит пластиковое окно стандартных размеров, вы можете узнать в прайсе нашей компании. Как видите, замена старых окон на современные по нашим ценам будет доступна для большинства желающих.</p>\n\n<table border="1">\n	<tbody>\n		<tr>\n			<th colspan="1" rowspan="2" style="background-color: rgb(228, 8, 126);"><strong><span style="color:#FFFFFF;">Изделие</span></strong></th>\n			<th colspan="2" rowspan="1" style="background-color: rgb(228, 8, 126);"><strong><span style="color:#FFFFFF;">Цена с монтажем, руб.</span></strong></th>\n		</tr>\n		<tr>\n			<th style="background-color: rgb(228, 8, 126);"><span style="color:#FFFFFF;">Панельный дом</span></th>\n			<th style="background-color: rgb(228, 8, 126);"><span style="color:#FFFFFF;">Кирпичный дом</span></th>\n		</tr>\n		<tr>\n			<td colspan="1" rowspan="1"><br />\n			<img alt="" src="/files/pictures/images/7.gif" style="width: 153px; height: 119px; float: left;" /></td>\n			<td colspan="1" rowspan="1">\n			<p style="text-align: center;"><span style="color:#e4087e;"><strong>9850</strong></span></p>\n			</td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>11850</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1" rowspan="1" style="text-align: center;"><img alt="" src="/files/pictures/images/8.gif" style="width: 223px; height: 116px; float: left;" /></td>\n			<td style="text-align: center;">\n			<p><span style="color:#e4087e;"><strong>13960</strong></span></p>\n			</td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>15880</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1" style="text-align: center;"><img alt="" src="/files/pictures/images/2.gif" style="width: 153px; height: 188px; float: left;" /></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>14950</strong></span></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>16880</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1" style="text-align: center;"><img alt="" src="/files/pictures/images/5.gif" style="width: 153px; height: 190px; float: left;" /></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>17450</strong></span></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>19380</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1" style="text-align: center;"><img alt="" src="/files/pictures/images/6-1.gif" style="width: 153px; height: 166px; float: left;" /></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>16840</strong></span></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>17670</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1" style="text-align: center;"><img alt="" src="/files/pictures/images/3.gif" style="width: 223px; height: 165px; float: left;" /></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>17760</strong></span></td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>20170</strong></span></td>\n		</tr>\n	</tbody>\n</table>\n\n<p><a href="/services/otdelka-plastikovyh-okon#holodilnik">Стоимость отделки холодильника под окном</a></p>\n\n<div class="accordion">\n<h2>Нестандартные окна</h2>\n\n<div>\n<p>В представлении большинства клиентов, нестандартное окно &ndash; это дорого. Мы сможем доказать вам обратное, когда сделаем по вашему закажу расчёт стоимости пластиковых окон в Новосибирске. Посмотрите, какие варианты окон и отделки вам доступны.</p>\n\n<div class="mark-green">\n<p>Что такое нестандартное остекление? Это панорамное остекление, необычная форма оконного проёма, необычные материалы окна или цвет рам. Неважно, подбираете ли вы окно под цвет и материал фасада или интерьера, цены на дешёвые пластиковые окна от нашей компании вас приятно удивят.</p>\n\n<p>Мы, как производители, учитываем в своей работе множество важных нюансов, например, далеко не все знают, что при проектировании нестандартных окон важно учитывать ветровую нагрузку на них. Для того чтобы сделать такое окно надёжным, мы используем специальные усилители в составе рамы.</p>\n</div>\n\n<p>Обратите внимание на наши цены на дачные пластиковые окна в Новосибирске &mdash; нестандартные окна особенно часто заказывают при отделке загородной недвижимости.</p>\n\n<p>Кроме этого, мы предлагаем не только возможность выбрать форму, размер или цвет окна, но и материал, из которого он будет изготовлен. Наши окна идеально подходят к материалу домов, потому и служат максимально долго.</p>\n\n<p>После изучения наших цен, позвоните менеджеру нашей компании. Он запланирует выезд инженера-конструктора для замеров, а затем предложит оптимальный вариант окон по подходящей именно для вас цене.</p>\n\n<div class="mark-pink">Рачет цен на изготовление окон ПВХ неправильных форм (круг, трапеция, треугольник) производится в офисе.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>\n\n<p>Сотрудничая с нами, вы можете быть уверены, что уложитесь в бюджет при замене окон любого размера, цвета и формы!</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Цены на пластиковые окна по прайсу</h2>\n\n<div>\n<p><a href="/files/pictures/files/prices.xlsx"><strong>Скачать прайс лист на пластиковые окна</strong></a></p>\n</div>\n</div>\n\n<h2>Кашированные цветные пластиковые окна</h2>\n\n<p>Белые окна &ndash; это стандартно. А что делать, если базовые решения не вписываются в ваш интерьер? Где <a href="/">заказать пластиковые окна в Новосибирске</a>, если нужен особый подход? Специалисты компании &laquo;Элитмонтаж&raquo; помогут вам решить эту задачу.</p>\n\n<p>Мы знаем, что многие наши клиенты хотят, чтобы новые окна отлично вписались в интерьер или фасад дома. Поэтому мы предлагаем кашированные пластиковые окна, чтобы вы смогли выбрать подходящий цвет из многообразия оттенков.</p>\n\n<h3>Стоимость каширования и образцы пленки:</h3>\n\n<table border="1">\n	<tbody>\n		<tr>\n			<th style="background-color: rgb(228, 8, 126);"><strong><span style="color:#FFFFFF;">Каширование</span></strong></th>\n			<th style="background-color: rgb(228, 8, 126);"><strong><span style="color:#FFFFFF;">Стоимость,&nbsp; руб. за м.п. </span></strong></th>\n		</tr>\n		<tr>\n			<td>С 1 стороны</td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>150</strong></span></td>\n		</tr>\n		<tr>\n			<td>С 2 сторон</td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>200</strong></span></td>\n		</tr>\n		<tr>\n			<td>Со стороны притвора</td>\n			<td style="text-align: center;"><span style="color:#e4087e;"><strong>225</strong></span></td>\n		</tr>\n	</tbody>\n</table>\n<!--<table>\n	<tbody>\n		<tr>\n			<td>\n			<div class="gallery" style="float: left; padding: 5px; text-align: center;"><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/mah.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Махагони</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/golddub.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Золотой дуб</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/naturedub.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Натуральный дуб</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/lightdub.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Светлый дуб</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/darkdub.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Темный дуб</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/bolotdub.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Болотный дуб</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/darkbroun.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Темно-коричневый</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/grey.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Серый</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/darkred.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Красный</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/green.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Зеленый</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/lightgrey.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Светло-серый</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/antr.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Антрацитово-серый</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/duglas.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Полосатый дуглас</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/vine.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Винно-красный</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/silver.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Металлик серебро</span></div>\n\n			<div style="float:left; padding: 5px; text-align: center"><img alt="" src="/files/pictures/images/vishnya.jpg" style="width: 100px; height: 100px;" /><br />\n			<span style="font-size:9px;">Вишня амаретто</span></div>\n			</td>\n		</tr>\n	</tbody>\n</table> -->', '', '', '', '', 'services'),
(19, 1, 'Веранды, беседки, теплицы - остекление', '<p>Остекление веранд, беседок, теплиц по индивидуальному заказу.</p>\n', '<h1>Остекление веранд и беседок&nbsp;</h1>\n\n<p style="font-size: 12px; line-height: 16px;">У вас есть коттедж или загородный дом с садом, которым вы с огромным удовольствием занимаетесь с ранней весны до поздней осени? Или вы просто любите отдыхать среди цветущих кустов и пышной экзотической зелени? И иногда кажется ужасно обидным, что лето в Сибири такое короткое, и большинство растений у нас невозможно выращивать. Но решение есть! <a href="/">Компания &laquo;Элитмонтаж&raquo;</a>, производящая и устанавливающая пластиковые окна в Новосибирске, поможет вам с остеклением тёплых террас, беседок, оранжерей и теплиц в Новосибирске &mdash; так вы сможете устроить зимний сад, который будет радовать вас круглый год.&nbsp;</p>\n\n<p style="font-size: 12px; line-height: 16px;">По вашему проекту мы выполним любое остекление теплиц, веранд, беседок, установим пластиковые стеклопакеты, рассчитаем нагрузку и создадим конструкции, которые будут устойчивы даже к очень сильным ветрам, дождям и снегу.&nbsp;</p>\n\n<p style="font-size: 12px; line-height: 16px;">Застекленные веранды и беседки подарят вам тепло и уют, в них вы сможете круглогодично собираться с друзьями, наслаждаться цветущими экзотическими растениями, отдыхать среди зелени.&nbsp;</p>\n\n<p style="font-size: 12px; line-height: 16px;">Стоимость таких работ определяется индивидуально, в зависимости от объема и сложности работ. Но даже эти работы в нашей компании вы можете получить оплатить <a href="/pay#rassrochka">в рассрочку</a>, а также &ndash; воспользоваться предложениями раздела &laquo;Скидки и акции&raquo;. Мы найдём подходящее решение для любого бюджета!&nbsp;</p>\n', '', '', '', '', 'services'),
(22, 1, 'Входные группы и ПВХ двери', '<p>Входные группы и пластиковые двери на заказ.&nbsp;</p>\n', '<h1>Установка пластиковых дверей и входных групп</h1>\n\n<p><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/vhodnaya-gruppa.jpg" style="width: 180px; height: 180px; float: left; margin-left: 10px; margin-right: 10px;" />Благодаря современным технологиям производства, клиентам компании &laquo;Элитмонтаж&raquo; доступна для заказа входная группа для магазина, офиса, подъезда, частного дома и любого общественного помещения.</p>\n\n<p>Такие конструкции легко вписываются в любой интерьер, поэтому пользуются чрезвычайно высоким спросом. Их достоинства сможете оценить и вы.&nbsp;</p>\n\n<h2>&nbsp;</h2>\n\n<h2>&nbsp;</h2>\n\n<h2>Преимущества&nbsp;</h2>\n\n<ul>\n	<li>Современный внешний вид и разнообразие возможных оттенков</li>\n	<li>Прочность и долговечность</li>\n	<li>Высокая звуко- и теплоизоляция</li>\n	<li>Устойчивость к влажности и перепадам температур</li>\n	<li>Доступная цена</li>\n</ul>\n\n<div class="accordion">\n<h3>Любое назначение</h3>\n\n<div>\n<p>Двери из пвх используются очень широко. Благодаря элегантному внешнему виду, их устанавливают в административных, торговых и офисных зданиях. Благодаря устойчивости к влажности, вы можете купить пластиковую дверь для бани и быть уверенными, что она прослужит десятилетия. А учитывая их высокие теплоизоляционные свойства, заказать пластиковую дверь на лоджию будет лучшим решением для любой квартиры.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h3>Для любого интерьера</h3>\n\n<div>\n<p>Традиционно клиенты выбирают универсальный белый цвет. Но для некоторых интерьеров и фасадов зданий куда лучше подойдут пластиковые двери под дерево или цветные. Мы изготавливаем изделия любого оттенка, при этом стоимость каширования пластиковой двери в компании &laquo;Элитмонтаж&raquo; остается весьма доступной.&nbsp;</p>\n</div>\n</div>\n\n<div class="accordion">\n<h3>Любая конфигурация</h3>\n\n<div>\n<p>В нашем ассортименте всегда присутствуют конструкции с различными боковыми панелями, одностворчатые, двустворчатые.&nbsp;</p>\n</div>\n</div>\n\n<div class="accordion">\n<h3>С теплоизоляцией и без нее</h3>\n\n<div>\n<p>Помимо широкого выбора оттенков, мы предлагаем и выбор различных материалов. У нас вы можете заказать проектирование и дизайн пластиковой входной группы на основе алюминиевого профиля и на основе профиля пвх.&nbsp;</p>\n\n<p>&laquo;Холодные&raquo; варианты изготавливаются из профиля без терморазрыва, комплектуются обычными стёклами или наполняются пвх.</p>\n\n<p>В &laquo;тёплые&raquo; же устанавливаются стеклопакеты или сэндвич-панели. У нас вы можете купить пластиковую входную дверь со стеклом (стеклопакетом), установить её на входе в любое здание и быть уверенным, что конструкция сохранит тепло в помещении.</p>\n</div>\n</div>\n\n<h2>Установка и монтаж входных групп</h2>\n\n<p>Детали установки зависят от многих параметров. Например, устройство распашных пластиковых дверей требует тщательного изучения проёма. В большинство проемов устанавливаются конструкции стандартного размера. Но даже если у вас нестандартный проем, это не проблема &ndash; мы изготовим и установим входную группу по любым размерам, при необходимости дополним входную группу глухими окнами и другими элементами.&nbsp;</p>\n\n<p>Процесс установки включает в себя подготовку проёма, установку и укрепление дверной рамы, монтаж пластиковой двери, герметизацию монтажных швов, отделку откосных систем. Эти работы так же, как и все другие, например, утепление и <a href="/services/osteklenie-balkonov-i-lodzhiy">остекление лоджий</a> и изготовление окна на заказ, требуют высокого уровня мастерства, поэтому выполняются только опытными специалистами. Мы гарантируем высокое качество!</p>\n\n<h3>Стоимость</h3>\n\n<p>Когда-то изделия из пвх были экзотикой и стоили довольно дорого. Сегодня это один из самых выгодных вариантов, особенно, если вы обращаетесь не к посреднику, а к производителю. Например, цена на пластиковые двери в Новосибирске от компании &laquo;Элитмонтаж&raquo; является одной из самых низких в регионе.</p>\n\n<p>Каждый клиент может рассчитывать на индивидуальный подход, поэтому мы предлагаем узнать точную стоимость входной пластиковой двери для вас у консультанта. После уточнения деталей и проведения замеров вы убедитесь, что эта цена вам понравится.&nbsp;</p>\n\n<p>В компании &quot;Элитмонтаж&quot; вы так же можетье заказать <a href="/services/remont-i-otdelka-vhodnyh-grupp-i-pvh-dverey">ремонт и отделку входной группы</a>.&nbsp;</p>\n', '', '', '', '', 'services');
INSERT INTO `contents_descriptions` (`content_id`, `lang_id`, `content_title`, `content_teaser`, `content_body`, `content_menu`, `content_var_field1`, `content_var_field2`, `content_text_field`, `module`) VALUES
(9, 1, 'Ремонт окон', '<p>Ремонт, регулировка оконных конструкций любой сложности, комплектующие.</p>\n', '<h1>Ремонт и регулировка пластиковых окон</h1>\n\n<h2>Регулировка пластиковых окон&nbsp;</h2>\n\n<p>Если вы поставили окно несколько лет назад, то сейчас, возможно, возникли какие-то проблемы с фурнитурой. Через какое-то время после активного использования может выйти из строя оконная ручка, могут возникнуть трудности с закрыванием окон, иногда из окна начинает дуть. Все эти вопросы решит простая регулировка пластиковых окон, которую выполнят наши специалисты:</p>\n\n<ul>\n	<li>Мы отрегулируем прижим створки окна;&nbsp;</li>\n	<li>Устраним провисание створки окна;&nbsp;</li>\n	<li>Почистим и обработаем специальными средствами фурнитуру;&nbsp;</li>\n	<li>Избавим вас от сквозняка.&nbsp;</li>\n</ul>\n\n<p>Просто позвоните в сервисную службу нашей компании, чтобы наши мастера продлили срок службы ваших окон на долгие годы!&nbsp;</p>\n\n<h2>Ремонт пластиковых окон</h2>\n\n<p>Клиенты компании &laquo;Элитмонтаж&raquo; знают, что качественный профиль пластиковых окон надёжен и не требует особого ухода. Кроме этого, специалисты сервисной службы могут доказать, что ремонт пластиковых окон в Новосибирске нашим клиентам не нужен. Хотите узнать почему? Мы предотвращаем самые частые поломки с помощью простых решений:&nbsp;</p>\n\n<ul>\n	<li>Устанавливаем ограничители (гребенки) чтобы избежать вываливания створки окна;&nbsp;</li>\n	<li>Встраиваем микролифт для створки, чтобы избежать провисания;&nbsp;</li>\n	<li>Устанавливаем дополнительные элементы для микропроветривания;&nbsp;</li>\n	<li>Монтируем блокиратор поворота ручки &mdash; т. е. детский замок.&nbsp;</li>\n</ul>\n\n<p>Но даже если вы заказывали окна не у нас, мы готовы выполнить ремонт пластиковых окон в Новосибирске для вас.&nbsp;</p>\n\n<p>Обращайтесь, если вам требуется изготовление <a href="/services/otdelka-plastikovyh-okon">москитной сетки</a>, устранение конденсата, сквозняка, грибка и плесени, замена стекла и фурнитуры, обновление отливов и откосов. Мы исправим недостатки неправильного монтажа, произведём необходимый ремонт пластиковых окон и заставим их работать без неприятных сюрпризов для вас. Не хотите переплачивать за переустановку окон? Мы предлагаем разумную альтернативу!&nbsp;</p>\n\n<div class="accordion">\n<h2>Замена стеклопакетов</h2>\n\n<div>\n<p>Несмотря на то, что разбить стеклопакет не так-то просто, это иногда случается. Обычно это вызывает ряд проблем, потому что замена стеклопакета в пластиковых окнах &ndash; сложная работа. Но специалистам компании &laquo;Элитмонтаж&raquo; она по плечу.&nbsp;</p>\n\n<h3>Придётся ли менять окно целиком?&nbsp;</h3>\n\n<p>Если вы разбили стекло в пластиковом окне, понадобится заменить лишь пакет стёкол. Замена стеклопакета в пластиковых окнах гораздо дешевле полной замены окна.&nbsp;</p>\n\n<h3>Почему нельзя поменять только одно стекло?&nbsp;</h3>\n\n<p>Потому что стеклопакет &ndash; это герметичная конструкция из двух, трёх или четырёх стёкол. Чтобы окно сохраняло тепло и оберегало вас от шума, необходимо сохранить эту герметичность. Поэтому замена только одного стекла, как в обычных деревянных рамах, невозможна.&nbsp;</p>\n\n<h3>В какие сроки нужно поменять разбитое стекло?&nbsp;</h3>\n\n<p>Обратитесь к нам сразу, как только вы заметили даже небольшую трещину на стекле. Своевременный ремонт не позволит грибкам и плесени разрушить фурнитуру окна, и вы получите новые стеклопакеты для пластиковых окон без дополнительных затрат. Не переживайте о сроках и стоимости ремонта. Ремонт будет выполнен быстро и по самым выгодным ценам.&nbsp;</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Замена фурнитуры в пластиковых окнах</h2>\n\n<div>\n<p>В компании &laquo;Элитмонтаж&raquo; вы можете не только <a href="/">заказать пластиковые окна</a>. Если вам требуется полная или частичная замена фурнитуры на пластиковых окнах &ndash; мы тоже будем рады вам помочь. Эта работа и последующая <a href="/services/otdelka-plastikovyh-okon">отделка пластиковых окон</a> будут сделаны качественно и в срок.</p>\n</div>\n</div>\n', '', '', '', '', 'services'),
(10, 1, 'Отделка окон', '<p>Описание вариантов отделки откосов, стены (или холодильника) под окном, материалы.</p>\n', '<h1>Наружная и внутренняя отделка пластиковых окон</h1>\n\n<p>Как улучшить внешний вид фасада здания и защитить ваши новые окна от образования конденсата? Вам требуется качественная <strong>отделка пластиковых окон</strong> снаружи. Внешняя отделка должна подходить фасаду дома и защищать монтажные швы от влаги.</p>\n\n<p>Специалисты компании &laquo;Элитмонтаж&raquo; используют различные материалы для наружной отделки. Это штукатурка, сэндвич-панели, пенополиуретановая лента, пластиковые откосы и другие материалы. Но большее внимание клиенты уделяют внутренней отделке.</p>\n\n<div class="mark-like">Всегда важен широкий выбор материалов, который позволит удачно вписать новые окна в интерьер. Поэтому отделка пластиковых окон внутри помещения, так же, как и внутренняя отделка балконов и лоджий требует высокого мастерства. Мы используем практически все виды материалов: <a href="/services/plastikovye-stenovye-paneli">пластиковые панели</a>, <a href="/services/evrovagonka">евровагонку</a>, гипсокартон, штукатурку.&nbsp;</div>\n\n<p>Каким бы ни был дизайн помещения, в нашем ассортименте всегда найдётся подходящее решение.</p>\n\n<h2><a id="holodilnik" name="holodilnik"></a>Отделка холодильника под окном</h2>\n\n<p>В квартирах многих наших клиентов есть удобная ниша &ndash; так называемый зимний холодильник. После замены окон его внешний вид часто не вписывается в интерьер.</p>\n\n<p><strong>Отделка холодильника под окном</strong> &ndash; одна из самых востребованных услуг, которые мы предлагаем. Наши специалисты не только защитят такой холодильник от влаги и морозов, но и установят вам современные пластиковые полки и двери.&nbsp;</p>\n\n<table border="1">\n	<tbody>\n		<tr>\n			<th colspan="2" style="background-color: rgb(228, 8, 126);"><span style="color:#FFFFFF;">Стандартная отделка сендвичем</span></th>\n			<th style="background-color: rgb(228, 8, 126);"><span style="color:#FFFFFF;">Стоимость, руб. </span></th>\n		</tr>\n		<tr>\n			<td colspan="1" rowspan="1"><img alt="" src="/files/pictures/images/holodilnik.gif" style="width: 169px; height: 119px; margin-left: 10px; margin-right: 10px; float: left;" /><br />\n			&nbsp;</td>\n			<td colspan="2" rowspan="1">\n			<p style="text-align: center;">&nbsp;</p>\n\n			<p style="text-align: center;"><span style="color:#e4087e;"><strong>5500</strong></span></p>\n\n			<p>&nbsp;</p>\n			</td>\n		</tr>\n		<tr>\n			<td colspan="1" rowspan="1" style="text-align: center;"><img alt="" src="/files/pictures/images/holodilnik2.gif" style="width: 209px; height: 119px; margin: 10px; float: left;" /></td>\n			<td colspan="2" rowspan="1" style="text-align: center;">\n			<p>&nbsp;</p>\n\n			<p><span style="color:#e4087e;"><strong>6500</strong></span></p>\n\n			<p>&nbsp;</p>\n			</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Чтобы подобрать оптимальную отделку, получите бесплатную консультацию нашего специалиста.&nbsp;</p>\n\n<div class="accordion">\n<h2>Откосы, подоконники, уголки для пластиковых окон</h2>\n\n<div>\n<p>Знаете ли вы, как не допустить разрушение оконного проёма? Какие климатические особенности должны учитываться при замене окон? Это серьёзные вопросы, разобраться с которыми помогут специалисты компании &laquo;Элитмонтаж&raquo;.</p>\n\n<table border="1">\n	<tbody>\n		<tr>\n			<th colspan="2" style="background-color: rgb(228, 8, 126);"><span style="color:#FFFFFF;">Вид работ</span></th>\n			<th style="background-color: rgb(228, 8, 126);"><span style="color:#FFFFFF;">Стоимость, руб. </span></th>\n		</tr>\n		<tr>\n			<td colspan="1">Отделка внутренних откосов окон пластиковыми материалами</td>\n			<td colspan="2"><span style="color:#e4087e;"><strong>1500-3000</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1">Отделка внешних откосов окон пластиковыми материалами</td>\n			<td colspan="2"><span style="color:#e4087e;"><strong>2500-3500</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1">Отделка оцинкованным железом</td>\n			<td colspan="2"><span style="color:#e4087e;"><strong>600 руб./м.кв.</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1">Уголок ПВХ для скрытия пенных швов&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>\n			<td colspan="2"><span style="color:#e4087e;"><strong>200 руб./м.кв.</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="3" style="background-color: rgb(228, 8, 126); text-align: center;"><strong><span style="color:#FFFFFF;">Установка ПВХ подоконника, длина, см.:</span></strong></td>\n		</tr>\n		<tr>\n			<td colspan="1">150, 200, 250</td>\n			<td colspan="2" style="text-align: center;"><span style="color:#e4087e;"><strong>500 руб./м.кв.</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1">300, 350, 400, 500</td>\n			<td colspan="2" style="text-align: center;"><span style="color:#e4087e;"><strong>600 руб./м.кв.</strong></span></td>\n		</tr>\n		<tr>\n			<td colspan="1">600, 700</td>\n			<td colspan="2" style="text-align: center;"><span style="color:#e4087e;"><strong>900 руб./м.кв.</strong></span></td>\n		</tr>\n	</tbody>\n</table>\n\n<p>При замене окон необходимо заделать все трещины в оконном проёме. Только после этого можно установить откосы для пластиковых окон. Материал для отделки всегда выбирается с учётом состояния здания и климата. На этот выбор влияет и материал стен. Мы подберём оптимальное решение для кирпичных, деревянных, панельных или монолитных домов.&nbsp;</p>\n\n<table cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td>\n			<div class="mark-green">Важно, чтобы материалы были морозоустойчивыми и не впитывали влагу.\n			<p>Отделка окон пластиковыми откосами - наиболее выгодное и популярное решение, которое мы предлагаем. При правильной установке пластик прослужит долгие годы.</p>\n			</div>\n			</td>\n			<td>\n			<p>Материалы для отделки должны сохранять тепло. Поэтому установка откосов всегда производится с помощью специальных материалов, их выбор велик.</p>\n\n			<p>Например, могут использоваться пластиковые откосы, содержащие дополнительный слой утеплителя.&nbsp;</p>\n			</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Благодаря огромному опыту монтажных и отделочных работ, мы гарантируем, что наружные откосы для пластиковых окон выдержат и высокую влажность, присущую нашему региону, и резкие перепады температур.</p>\n\n<p>При заказе пластиковых окон в компании &laquo;Элитмонтаж&raquo; вы получите подробную консультацию специалистов по выбору материалов для отделки откосов.</p>\n\n<p>Позвоните сейчас, и мы подберём оптимальное для вас решение!&nbsp;</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Комплектующие для пластиковых окон</h2>\n\n<div>\n<p>Для защиты от насекомых и уличной пыли, вам будут необходимы москитные сетки на окна. Они изготавливаются из специального полотна, которое надёжно крепится и очень легко моется обычной мыльной водой. Рамы для москитных сеток могут быть разных цветов, при желании вы сможете превратить ее в интересный элемент дизайна.</p>\n\n<p>Обратите внимание, что в компании &laquo;Элитмонтаж&raquo; вы можете <a href="/">заказать пластиковые окна</a> и комплектующие для них <a href="/pay#rassrochka">в рассрочку</a>. Позвоните нам, чтобы узнать подробности!&nbsp;</p>\n</div>\n</div>\n', '', '', '', '', 'services'),
(11, 1, 'Производство окон и дверей', '<p>Описание процесса производства пластиковых и алюминиевых конструкций на нашем заводе.</p>\n', '<h1>Производство пластиковых окон и конструкций в Новосибирске</h1>\n\n<p>Если вы ищете, кому доверить замену оконных рам, если вы предпочитаете работать с производителями, а не с посредниками, то небольшая виртуальная экскурсия по этапам нашего производства будет вам полезна.&nbsp;</p>\n\n<p>Наша специализация &ndash; это не только изготовление пластиковых окон в Новосибирске, так же мы изготавливаем ПВХ и алюминиевые конструкции и двери. И мы готовы рассказать, из чего состоит наша работа, как проходит весь производственный процесс. Благодаря сотрудничеству с сибирскими производителями пвх и алюминиевых профилей, процесс изготовления мы довели до совершенства.</p>\n\n<p>Особая гордость компании &laquo;Элитмонтаж&raquo; &mdash; это высочайшее качество изготовления продукции, добиться высокой степени надёжности которой непросто. Выбирая поставщиков профиля для производства оконных и балконных конструкций, мы сделали свой выбор в пользу тех, кто знает о климате Сибири не понаслышке. Мы работаем с двумя производителями:</p>\n\n<h2>ПВХ профиль фирмы Exprof</h2>\n\n<p>На их основе мы создаём продукцию для жилых домов и неотапливаемых помещений. Широкий выбор позволит вам воплотить в реальность любые интерьерные решения. Влаго- и морозоустойчивые конструкции для остекления балконов по низким ценам, профили с приточной системой вентиляции для квартир и офисов и с пятью камерами &mdash; они надёжно устанавливаются даже в оконных проёмах, имеющих дефекты.&nbsp;</p>\n\n<h2>Алюминиевый профиль фирмы &laquo;СибПрофиль&raquo;</h2>\n\n<p>Рамы на их основе выдержат любые перепады температур, они оптимально подходят для установки на большой высоте, придают фасаду любого здания более современный и аккуратный вид, создают ощущение лёгкости. Мы выбираем сочетание мощной защиты от холода и шума и внешней эстетичности.&nbsp;</p>\n\n<h2>Изготовление рам</h2>\n\n<p>Производство стеклопакетов высочайшего качества &mdash; это прерогатива нашего проверенного партнера, лидера рынка &ndash; торгово-производственной компании М1. Это гарантирует то, что стеклопакеты будут изготовлены с соблюдением всех норм и стандартов, и при эксплуатации не доставят неприятных неожиданностей.&nbsp;</p>\n\n<p>Изготовление алюминиевых конструкций мы так же доверяем нашим партнёрам &mdash; компании &laquo;СибПрофиль&raquo;.</p>\n\n<p>Следующий этап после выбора материала для рам и изготовления стеклопакетов &ndash; это производство самих конструкций. Производители пластиковых окон в Новосибирске часто предлагают своим клиентам продукцию посредников, и иногда ее качество сложно предугадать. Компания &laquo;<a href="/">Элитмонтаж</a>&raquo; работает на собственном оборудовании, поэтому имеет возможность не только контролировать качество продукции, но и выполнять заказы в кратчайшие сроки. Хотите узнать, как работает наш завод по производству пластиковых окон?&nbsp;</p>\n\n<p>Изготовление рамы на основе готового профиля происходит со строгим соблюдением технологии. Опытная бригада рабочих, импортное современное оборудование, постоянный контроль качества изделий &mdash; это залог того, что продукция, которую вы заказали в компании &laquo;Элитмонтаж&raquo; прослужит вам долгие годы.&nbsp;</p>\n\n<p>Весь процесс включает в себя порядка 100 этапов, основные из них:</p>\n\n<ul>\n	<li>нарезка</li>\n	<li>армирование</li>\n	<li>сваривание и зачистка швов</li>\n	<li>навешивание фурнитуры</li>\n	<li>вставка стеклопакета и шпатика</li>\n</ul>\n\n<p>И на каждом этапе проводится необходимый контроль качества, ведь любое нарушение порядка работы приведет к изготовлению бракованной продукции.</p>\n\n<p>Благодаря тому, что процесс производства в компании &laquo;Элитмонтаж&raquo; отлично налажен, мы можем удовлетворить потребности любого клиента.</p>\n\n<div class="accordion">\n<p>Любая толщина:</p>\n\n<div>\n<p>Мы работаем со всеми видами профилей: 3, 4 и 5-камерными.В зависимости от необходимого результата, мы подберём оптимальное количество камер при изготовлении вашего заказа.</p>\n</div>\n</div>\n\n<div class="accordion">\n<p>Любой цвет:</p>\n\n<div>\n<p>При производстве мы учитываем не только необходимую толщину и количество камер профиля, но и высокий спрос на кашированные окна и двери. Изготовление конструкций по этим технологиям вы можете заказать именно у нас. Если фасад здания или ваш интерьер требует индивидуального подхода, обратите внимание на цветные окна и двери. В наших силах подобрать практически любой оттенок для вас.</p>\n</div>\n</div>\n\n<div class="accordion">\n<p>Любая форма:</p>\n\n<div>\n<p>Для клиентов, которым требуются нестандартные решения, мы готовы предложить производство рам любой формы. Для вас мы изготовим и установим многоугольные и даже круглые конструкции. У нас есть все для того, чтобы воплотить ваши идеи в реальность.</p>\n</div>\n</div>\n\n<div class="accordion">\n<p>Любые решения:</p>\n\n<div>\n<p>Мы готовы помочь и с другими интерьерными решениями - производство пластиковых дверей и входных групп &ndash; ещё одна услуга, которую мы предлагаем.<br />\nЕсли вы хотите получить полный спектр услуг, и ищете производителя пластиковых дверей, мы предложим вам межкомнатные пластиковые двери для общественных помещений и офисов, двери для балконов в составе оконного блока, <a href="/services/plastikovye-dveri-i-vhodnye-gruppy">раздвижные и входные двери из ПВХ</a>.</p>\n</div>\n</div>\n\n<div class="accordion">\n<p>Любой объем:</p>\n\n<div>\n<p>Нам по силам заказы любого объёма. Наш опыт выполнения заказов как для частных лиц, так и для строительных организаций, будет полезен любому клиенту, который к нам обратится.</p>\n</div>\n</div>\n\n<p>Есть множество причин, чтобы выбрать компанию &laquo;Элитмонтаж&raquo;. Мы - &nbsp;надёжный производитель, для которого продажа окон в Новосибирске &ndash; это результат многолетней работы. Используйте наш опыт для создания уюта в вашем доме!&nbsp;</p>\n', '', '', '', '', 'services'),
(12, 1, 'Остекление лоджий', '<p>Описание этапов остекления балконов и лоджий, помощь в выборе типа и материала рам.</p>\n', '<h1>Остекление балконов и лоджий&nbsp;</h1>\n\n<p>Мало кто поспорит с тем, что застекленная лоджия &ndash; это красиво, удобно, практично. Защита от дождя, снега, ветра, пыли, шума, холода &ndash; все это дает услуга, которую предлагают фирмы по остеклению балконов. Когда вы выбираете, к кому обратиться, кто сможет застеклить балкон или лоджию в Новосибирске алюминиевым или пвх профилем под ключ, глаза разбегаются от обилия предложений и вариантов решения.</p>\n\n<p>Как сориентироваться во всем многообразии предложений? Как понять, какой вариант оптимален для вас, и при этом не разочароваться в результате?&nbsp;</p>\n\n<div class="mark">Обращайтесь к специалистам компании &laquo;Элитмонтаж&raquo; &mdash; мы подскажем, что выбрать, поясним, чем различаются варианты остекления балконов и лоджий &mdash; пластик или алюминий.</div>\n\n<h2>Холодное или теплое остекление лоджий в Новосибирске</h2>\n\n<p>По большому счету, существует два принципиально различающихся варианта, они различаются и материалами, которые используются, профилем, стеклопакетами, ну и, разумеется, <a href="/services/ceny-na-osteklenie-balkonov-i-lodzhiy">ценой</a>.</p>\n\n<p>Установка алюминиевой или пластиковой конструкции лоджии и стеклопакетов на балконе даст вам дополнительное помещение, которое вы сможете использовать по своему усмотрению. Но именно от типа остекления зависит, насколько широкие возможности у вас появятся.&nbsp;</p>\n\n<div class="accordion">\n<h2>Алюминиевое остекление лоджий и балконов</h2>\n\n<div>\n<p>Это возможность получить сухое, чистое холодное помещение, температура в котором зимой будет отличаться от уличной незначительно. Но при этом если вам нужно только место для хранения вещей, и вы хотите избавиться от сугробов и уличной грязи и пыли &ndash; то этот вариант подходит вам идеально.</p>\n\n<p>Монтаж алюминиевого балкона или лоджии выполняется в сжатые сроки, профессиональные монтажники быстро и качественно установят конструкции, откосы, подоконники, выполнят герметизацию.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Пластиковое остекление</h2>\n\n<div>\n<p>Его можно произвести с одновременным <a href="/services/uteplenie-balkonov-lodzhiy">утеплением балкона</a>. Это решение стоит дороже, но в итоге выгода для клиента очевидна &ndash; у него появляется не просто холодная кладовка, а полноценная комната, в которой можно обустроить зимний сад, тренажерный зал, кабинет. Также, возможно присоединить эти квадратные метры к комнате, и как следствие, заметно увеличить ее размер.</p>\n\n<p>Если вас пугает вопрос цены, то вы сами сможете убедиться, что застеклить балкон в хрущевке, панельном или кирпичном доме пластиком недорого, в принципе, возможно. Мы делаем все для того, чтобы наши клиенты не переплачивали за материалы и работу &ndash; собственное производство и надежные партнеры и поставщики гарантируют высокое качество итоговых конструкций.&nbsp;</p>\n\n<p>Вы можете позвонить и заказать расчет остекления лоджии или балкона нашим менеджерам &ndash; и вы сами увидите, что вы можете себе это позволить!&nbsp;</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Нестандартные варианты</h2>\n\n<div>\n<p>Большинство заказчиков выбирают традиционные способы остекления балконов, но иногда перед нами ставят интересные и необычные задачи. Например, последнее время набирают популярность <strong>фасадное (витражное) остекление лоджий и балконов</strong> до пола или панорамное остекление, в результате которого в вашем интерьере появляется новая оригинальная деталь - французское окно.</p>\n\n<p>Французское пластиковое окно зрительно расширяет пространство, повышает инсоляцию, появляется ощущение обилия света и воздуха.</p>\n\n<p>На визуальное расширение пространства влияют и раздвижные алюминиевые и пластиковые окна на балкон и лоджию &mdash; они тоже создают ощущение отсутствия границ.</p>\n\n<p>И в коттеджах, и квартирах есть еще одна нестандартная работа &ndash; создание крыши над балконами, верандами, террасами. Разумеется, если речь идет о квартире, то это будет остекление балконов на последнем этаже с монтажом козырька (крыши балкона) &ndash; без этого ни о какой защите от снега и дождя говорить не приходится.</p>\n</div>\n</div>\n\n<div class="mark">Почему с нами действительно выгодно сотрудничать?</div>\n\n<ul>\n	<li>Во-первых, собственное производство. Мы не перепродаём с наценкой чужие изделия, благодаря чему вы экономите свои деньги.&nbsp;</li>\n	<li>Во-вторых, особые предложения для строительных организаций. При заказе остекления для коттеджей или многоквартирных домов мы предложим максимальные скидки.&nbsp;&nbsp;</li>\n	<li>В-третьих, гарантия качества. Вы получаете наши обычные гарантии и отличное сервисное обслуживание при заказе любой сложности.&nbsp;</li>\n	<li>В-четвертых, дополнительные услуги. В частности, наши специалисты своими силами производят демонтаж лоджий и балконов с выносом строительного мусора.&nbsp;</li>\n</ul>\n\n<p>Помните, что вы обращаетесь к профессионалам, поэтому мы не только выслушаем ваши пожелания, но и сможем предложить свои идеи, чтобы сделать жилое пространство вашего дома лучше. Обратитесь в &laquo;ЭлитМонтаж&raquo;, и результат вас не разочарует! <a href="/">Заказать пластиковые окна</a> вы так же можете на самых выгодных условиях.</p>\n\n<p>В коттеджах, и квартирах есть еще одна нестандартная работа &ndash; создание крыши над балконами, верандами, террасами. Разумеется, если речь идет о квартире, то это будет остекление балконов на последнем этаже с монтажом козырька (крыши балкона) &ndash; без этого ни о какой защите от снега и дождя говорить не приходит</p>\n\n<table>\n</table>\n', '', '', '', '', 'services'),
(13, 1, 'Цены на балконы', '<p>Цены на остекление балконов и лоджий.</p>\n', '<h1>Цены на остекление балконов и лоджий в Новосибирске</h1>\n\n<p>Один из главных принципов работы компании &laquo;Элитмонтаж&raquo; &mdash; это производство и продажа доступной продукции для наших клиентов.&nbsp; Мы стараемся сделать наши цены абсолютно прозрачными для каждого заказчика, поэтому здесь вы можете узнать подробную информацию о том, сколько стоит застеклить балкон или лоджию под ключ в Новосибирске. Убедитесь, что в нашей компании цены могут быть только приятным сюрпризом для вас.</p>\n\n<h2><a id="price" name="price"></a>Цены на стандартное остекление балконов и лоджий:</h2>\n\n<table border="1" cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td style="background-color: rgb(228, 8, 126); border-color: rgb(228, 8, 126);"><strong><span style="color:#FFFFFF;">Остекление</span></strong></td>\n			<td style="background-color: rgb(228, 8, 126); border-color: rgb(228, 8, 126);"><strong><span style="color:#FFFFFF;">Конструкция, размеры</span></strong></td>\n			<td style="background-color: rgb(228, 8, 126); border-color: rgb(228, 8, 126);"><strong><span style="color:#FFFFFF;">Специальная цена, руб.&nbsp;</span></strong></td>\n			<td style="background-color: rgb(228, 8, 126); border-color: rgb(228, 8, 126);"><img alt="" src="/files/pictures/images/skidka.gif" style="width: 50px; height: 50px;" /></td>\n		</tr>\n		<tr>\n			<td colspan="1" rowspan="2"><strong>Алюминий</strong></td>\n			<td>\n			<p><strong>Балкон</strong></p>\n\n			<p>высота 1,4 м.-1,7 м.</p>\n\n			<p><span style="font-size: 12px; line-height: 16px;">ширина 2,2 м.-2,6 м.</span></p>\n			</td>\n			<td><img alt="" src="/files/pictures/images/alyuminievoe-osteklenie-balkona.gif" style="width: 200px; height: 120px;" /></td>\n			<td><strong><span style="color:#e4087e;">15000</span></strong>&nbsp;</td>\n		</tr>\n		<tr>\n			<td>\n			<p><strong>Лоджия</strong></p>\n\n			<p>высота &nbsp;1,4 м.-1,6 м.</p>\n\n			<p>ширина 2,2 м.-2,6 м. &nbsp; &nbsp; &nbsp;&nbsp;</p>\n\n			<p>&nbsp;</p>\n			</td>\n			<td><img alt="" src="/files/pictures/images/alyuminievoe-osteklenie-lodzhii.gif" style="width: 175px; height: 91px;" /></td>\n			<td><strong><span style="color:#e4087e;">10500</span></strong></td>\n		</tr>\n		<tr>\n			<td colspan="1" rowspan="2"><strong>Пластик</strong></td>\n			<td>\n			<p><strong>Балкон</strong></p>\n\n			<p>до 6 кв.м.</p>\n			</td>\n			<td><img alt="" src="/files/pictures/images/plastikovoe-osteklenie-balkona.gif" style="width: 200px; height: 120px;" /></td>\n			<td><strong><span style="color:#e4087e;">20000</span></strong></td>\n		</tr>\n		<tr>\n			<td>\n			<p><strong>Лоджия</strong></p>\n\n			<p>до 4 кв.м.</p>\n			</td>\n			<td><img alt="" src="/files/pictures/images/plastikovoe-osteklenie-lodzhii.gif" style="width: 175px; height: 90px;" /></td>\n			<td><strong><span style="color:#e4087e;">15000</span></strong></td>\n		</tr>\n	</tbody>\n</table>\n\n<h2>Что можно сделать при минимальном бюджете?</h2>\n\n<p>Избавиться от ветра, уличной пыли, шума, излишней влаги можно без особых затрат. Традиционно цены на остекление балконов и лоджий алюминиевым профилем ниже, чем на пластик. Именно этот способ каркасной защиты балкона мы советуем своим клиентам при небольшом бюджете. &nbsp;</p>\n\n<h2>Могут ли цены на нестандартное остекление быть доступными?</h2>\n\n<p>Многим нашим клиентам требуются нестандартные решения из-за особенностей фасада здания или интерьера квартиры. Цена при работе со сложными заказами далеко не всегда высока. В компании &laquo;Элитмонтаж&raquo; регулярно проводятся специальные акции, с помощью которых вы сможете сэкономить при установке окон любой формы и любого цвета.</p>\n\n<p>Например, вы планируете панорамное остекление и хотите знать, сколько стоит <a href="/services/osteklenie-balkonov-i-lodzhiy">французское остекление балкона или лоджии</a>. При оформлении заказа стоимость установки будет определяться индивидуально после проведения замеров и выбора материалов. Но вы можете не сомневаться &ndash; мы предложим самые выгодные решения для вас.</p>\n\n<div class="accordion">\n<h2>Как получить максимальную скидку?</h2>\n\n<div>\n<p>Если вы являетесь представителем строительной компании, то именно для вас мы приготовили самые выгодные предложения. При оптовом заказе компания &laquo;Элитмонтаж&raquo; гарантирует низкие цены на балконы и лоджии из алюминиевого и пластикового профиля с установкой в новостройках и коттеджных посёлках. С нами выгодно сотрудничать, потому что компания &laquo;Элитмонтаж&raquo; располагает собственным производством. Для нас не составит труда соблюсти не только технические требования клиентов, но и придерживаться самых строгих рамок бюджета.</p>\n\n<h2>Как узнать стоимость остекления балконов и лоджий под ключ?</h2>\n\n<p>Конечная стоимость такого заказа всегда рассчитывается индивидуально. При расчёте заказа мы учитываем множество факторов:</p>\n\n<ul>\n	<li>Тип здания (панельный, кирпичный, деревянный или монолитный дом);</li>\n	<li>Тип остекления (обычное или панорамное)</li>\n	<li>Тип отделки (холодный или тёплый вариант, выбор материалов и фурнитуры);</li>\n	<li>Тип профиля (пластик или алюминий);</li>\n	<li>Габариты;</li>\n	<li>Количество стекол в стеклопакете (от 2 до 5);</li>\n	<li>Тип открывания окон (раздвижной, распашной);</li>\n	<li>Дополнительная комплектация (козырьки, подоконники, отливы и т.д.);</li>\n	<li>Цвет профиля.</li>\n</ul>\n\n<p>Как учесть все эти нюансы и не переплатить при заказе? Примерную стоимость услуг вы можете узнать на нашем сайте, изучив <a href="/files/pictures/files/prices.xlsx">прайс на остекление балконов и лоджий</a>.</p>\n\n<p>Чтобы вы могли узнать точную стоимость необходимых услуг, вам понадобится консультация менеджера. С каждым клиентом мы работаем индивидуально. В кратчайшие сроки мы сделаем расчёт стоимости остекления балкона в хрущёвке или 6-метровой лоджии под ключ. Мы гарантируем, что подберём решение, которое обязательно впишется в ваш бюджет.</p>\n</div>\n</div>\n\n<p>Выбирайте подходящий вариант остекления и обращайтесь в компанию &laquo;Элитмонтаж&raquo;. Наши менеджеры всегда готовы сделать вам самое выгодное предложение.</p>\n', '', '', '', '', 'services');
INSERT INTO `contents_descriptions` (`content_id`, `lang_id`, `content_title`, `content_teaser`, `content_body`, `content_menu`, `content_var_field1`, `content_var_field2`, `content_text_field`, `module`) VALUES
(16, 1, 'Мебель для балкона', '<p>Мебель для балконов и лоджий - шкафы-купе, встроенные шкафы и другая мебель.</p>\n', '<h1>Мебель для балкона</h1>\n\n<p>Что традиционно хранят на балконе? Лыжи, удочки, заготовки, стремянки, велосипеды &ndash; у каждой семьи свой набор не самых удобных для хранения вещей. Поэтому встроенные шкафы и другая мебель для балкона и лоджии всегда проектируются индивидуально. Никакой <a href="/remont-i-obustroystvo-lodzhiy-balkonov">ремонт лоджий и балконов</a> не поможет привести их в порядок, если не установить мебель с подходящим именно вам наполнением и функционалом.</p>\n\n<table cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/shkaf-dlya-balkona.jpg" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/vstroennyy-shkaf-dlya-balkona.jpg" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/shkaf-kupe-dlya-balkona.jpg" style="width: 144px; height: 180px;" /></td>\n			<td>&nbsp;</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Чтобы сделать балкон удобным местом для хранения, нужна качественная и вместительная мебель, которая выдержит высокую влажность, прямое попадание солнечных лучей и перепады температур. Собственное <a href="/services/proizvodstvo-plastikovyh-okon-konstrukcij-v-Novosibirske">производство алюминиевых и пластиковых конструкций</a> компании &laquo;Элитмонтаж&raquo; позволяет предложить вам разнообразные решения этой задачи. Как и <a href="/services/otdelka-obshivka-balkonov">обшивка балконов</a>, изготовление мебели требует выбора качественных материалов. Мы используем дерево со специальной обработкой и пропиткой, пластик и алюминий.&nbsp;</p>\n\n<p>Важно подобрать мебель с учётом особенностей пространства, когда планируется ремонт и обустройство балконов.&nbsp;</p>\n\n<p>Если помещение невелико и вам важно обеспечить лёгкий доступ к полкам, мы рекомендуем заказать шкаф купе на балкон или лоджию. Раздвижные двери такого шкафа особенно удобны на узких балконах. Чтобы &nbsp;использовать каждый сантиметр полезного пространства, имеет смысл заказать не обычные, а встроенные угловые шкафы на балкон.</p>\n\n<p>Обращаясь к нам, вы можете быть уверены, что мы изготовим именно такие шкафы для балкона на заказ, которые помогут вам оптимально организовать хранение необходимых вещей.</p>\n', '', '', '', '', 'services'),
(17, 1, 'ПВХ стеновые панели', '<p>Монтаж пластиковых стеновых панелей в различных помещениях.</p>\n', '<h1>Монтаж пластиковых стеновых панелей</h1>\n\n<p>Сегодня для отделки таких помещений, как балкон, ванная, кухня всё чаще используются стеновые панели из пвх и материал, который настолько экологичен, что разрешён для использования даже в детских садах &ndash; декоративные стеновые панели мдф.</p>\n\n<p>Популярность этих материалов легко объяснить. При невысокой стоимости и абсолютной безопасности они устойчивы к влаге и перепадам температур. Такие панели &ndash; один из самых лёгких и надёжных способов отделки помещений.</p>\n\n<p>Компания &laquo;Элитмонтаж&raquo; предлагаем своим клиентам не только <a href="/">пластиковые окна в Новосибирске</a>, но и отделку пластиковыми панелями тех помещений, для которых особенно трудно подобрать надёжный и недорогой материал.</p>\n\n<div class="accordion">\n<h2>Для ванной комнаты и кухни</h2>\n\n<div>\n<p>Вместо традиционных материалов для помещений, в которых важно поддерживать чистоту, вы можете выбрать пластиковые стеновые панели для кухни и ванной комнаты.</p>\n\n<p>В отличие от обоев, они не деформируются от постоянного воздействия влаги, их легко мыть и они гораздо дешевле кафельной плитки. Влагостойкие стеновые панели для отделки ванной и кухни прослужат вам десятилетия, при этом их внешний вид не изменится.</p>\n\n<p>Обратите внимание, что в ванной комнате не только стены, но и потолок постоянно испытывается на прочность влагой и горячим паром. Поэтому краску или штукатурку необходимо регулярно обновлять. А потолок из пластиковых панелей абсолютно устойчив к такому воздействию и годами не требует никакого внимания, кроме чистки.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Для балкона и лоджии</h2>\n\n<div>\n<table align="left" cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td>\n			<p>Ежегодно компания &laquo;Элитмонтаж&raquo; выполняет сотни заказов на <a href="/services/osteklenie-balkonov-i-lodzhiy">остекление балконов и лоджий</a>. Но всё чаще вместе с этой услугой клиенты заказывают <a href="/services/otdelka-obshivka-balkonov">отделку балкона</a>. Поэтому мы рады предложить вам полный комплекс услуг.</p>\n\n			<p>Когда вы выбираете отделочные материалы, чтобы закончить благоустройство балкона, важно учитывать не только их влагостойкость, но и устойчивость к перепадам температур, грибкам и бактериям. Обшивка балкона пластиковыми стеновыми панелями &ndash; одно из лучших решений.</p>\n			</td>\n			<td>&nbsp;</td>\n			<td>\n			<div class="mark">\n			<p>Пластиковые панели могут быть реечными, листовыми или плиточными.</p>\n\n			<p>Выбор типа панели зависит от качества стены и желаемого результата.</p>\n			</div>\n\n			<p>Для завершения отделки используются плинтуса, уголки и карнизы в тон панелям.</p>\n\n			<p>Каждый вид пластиковых панелей позволяет создать уникальный современный интерьер.</p>\n			</td>\n		</tr>\n		<tr>\n			<td>\n			<p>Если вам важна экологичность, то обшивка балкона стеновыми мдф панелями подойдёт лучшего всего. Этот материал имеет фактуру и цвет, максимально приближенные к натуральному дереву.</p>\n\n			<div class="mark">Если вы ищете многообразие оттенков и цените безопасность материала, то отделка балкона стеновыми панелями из пвх позволит подобрать цвет, подходящий именно вашему интерьеру. Эти виды панелей применяются как для внутренней, так и для внешней отделки.</div>\n			</td>\n			<td>&nbsp;</td>\n			<td>\n			<p>Также при выборе материала для отделки важна их стоимость. В отличие от стоимости плитки и многих других материалов, цена на обшивку лоджии и стен помещений пвх панелями невелика. И это ещё один повод использовать их при ремонте.</p>\n\n			<p>Монтаж пластиковых панелей осуществляется либо на подготовленную стену, либо на обрешётку. Все стыки обязательно обрабатываются герметиком.</p>\n			</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>При необходимости при монтаже укладывается звукоизолирующий или теплоизолирующий слой для максимальной защиты от шума и холодов. По сравнению с отделкой помещения другими материалами, монтаж пластиковых панелей занимает минимальное количество времени.</p>\n\n<p>Примерную стоимость услуг по отделке помещений вы можете узнать на нашем сайте, изучив прайс. Но конечная цена на пластиковые стеновые панели с монтажом в Новосибирске будет известна только после консультации специалиста.</p>\n</div>\n</div>\n\n<p>Чтобы назвать точную стоимость работ, мы проведём необходимые замеры, изучим особенности стен и микроклимата помещения, учтём ваши пожелания к свойствам и дизайну материалов. После этого мы сможем предложить оптимальное по качеству и цене решение вашей задачи.</p>\n', '', '', '', '', 'services'),
(18, 1, 'Евровагонка', '<p>Отделка евровагонкой любых помещений, качественный натуральный материал.&nbsp;</p>\n', '<h1>Отделка евровагонкой</h1>\n\n<p><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/otdelka-evrovagonkoy.jpg" style="width: 150px; height: 150px; float: left; margin-left: 10px; margin-right: 10px;" />Ещё одна популярная услуга, которая входит в список работ <a href="/">компании &laquo;Элитмонтаж&raquo;</a> &mdash; отделка лоджий и балконов деревом или, как это принято называть &mdash; евровагонкой. Это классика, которая никогда не выходит из моды. О преимуществах решения обшить балкон вагонкой расскажут наши специалисты.</p>\n\n<h2>Лучшие породы дерева</h2>\n\n<p>Для этих работ используется только натуральное дерево, чаще всего &ndash; сосна и лиственница. Для особых ценителей мы можем предложить евровагонку из ценных пород дерева: липы, вишни, кедра, дуба и других. Клиентам, которые планируют <a href="/services/remont-i-obustroystvo-lodzhiy-balkonov">ремонт балкона или лоджии</a>, мы предлагаем евровагонку высшего качества.</p>\n\n<p>Чтобы вы были довольны своим выбором, отделка балкона и лоджии евровагонкой в нашей компании подразумевает использование только лучших сортов дерева &ndash; 0, 1 или экстра.</p>\n\n<h2>Надёжность и долговечность</h2>\n\n<p>Как известно, балкон и лоджия &ndash; это помещения со сложным микроклиматом. Евровагонке приходится противостоять перепадам температур и высокой влажности. Что мы делаем для того, чтобы материал оставался в первоначальном состоянии?</p>\n\n<p>Во-первых, при отделке балконов и лоджий евровагонкой должна использоваться правильная технология. Этим материалом обшиваются стены и потолок, а на пол при желании клиента укладывается паркетная доска.</p>\n\n<p>Во-вторых, при отделке используется специальная пропитка. Она защищает евровагонку от бактерий и грибков и не позволяет влаге впитываться. Если влажность на вашем балконе слишком высока и даже <a href="/services/montazh-plastikovyh-okon">монтаж пластиковых окон</a> не помог от неё защититься, для отделки мы порекомендуем лиственницу. Этот уникальный материал становится только крепче от влаги.&nbsp;</p>\n\n<h2>Экологичность</h2>\n\n<p>Пожалуй, одно из главных достоинств отделки помещения евровагонкой &ndash; это создание уникального микроклимата, в котором не просто легко дышится, но и очень полезно для здоровья находиться.</p>\n\n<h2>Решения на любой вкус и кошелёк</h2>\n\n<p>Многие наши клиенты выбирают для отделки дерево, поскольку этот материал обладает неповторимым рисунком и даёт возможность создавать уникальные интерьеры. Но иногда сделать выбор в пользу отделки натуральным материалом не позволяет цена. Не знаете, сколько стоит обшить балкон или лоджию вагонкой? Сомневаетесь, что такое решение будет вам по карману?</p>\n\n<p>Компания &laquo;Элитмонтаж&raquo; предлагает различные варианты на выбор своим клиентам. Вы убедитесь, что наша цена на обшивку балконов и лоджий евровагонкой в Новосибирске будет выгодна для вас. Для решений эконом класса могут быть использована евровагонка из недорогих сортов дерева, по стоимости она соотносима с самыми экономичными вариантами наружной отделки, например, <a href="/services/montazh-saydinga-novosibirsk">отделка сайдингом</a> находится примерно в той же ценовой категории. Для взыскательных клиентов мы предложим евровагонку из ценных пород дерева.&nbsp;</p>\n\n<p>Цена на эту услугу определяется индивидуально с учётом пожеланий каждого клиента. Обязательно обратитесь в нашу компанию, чтобы точно узнать, сколько стоит обшить балкон вагонкой в вашем случае. Мы сумеем подобрать вариант, который будет выгоден для вас.</p>\n', '', '', '', '', 'services'),
(20, 1, 'Монтаж сайдинга', '<p>Монтаж сайдинга в Новосибирске - обшивка домов, балконов и лоджий.&nbsp;</p>\n', '<h1>Монтаж сайдинга в Новосибирске</h1>\n\n<p>Сегодня сайдинг &ndash; один из самых востребованных материалов для отделки. Наш опыт подтверждает высокое качество этого покрытия. Сайдинг идеально подходит для отделки домов, балконов и лоджий, цоколей и фундаментов. А цена на монтаж винилового или металлического сайдинга под бревно, камень или кирпич выгодно отличается от стоимости многих других отделочных материалов.</p>\n\n<p>Благодаря тому, что компания &laquo;Элитмонтаж&raquo; не только изготавливает лучшие <a href="/">пластиковые окна в Новосибирске</a>, но и оказывает услуги по отделке помещений, мы досконально изучили свойства сайдинга и готовы рассказать о том, как он может быть вам полезен.</p>\n\n<div class="mark-green">Стоимость обшивки любой поверхности сайдингом без учета стоимости материала&nbsp; (уточняется при заказе) - <strong>600 рублей</strong> за м.кв.</div>\n\n<h2>Сайдинг для отделки домов</h2>\n\n<p>Для владельцев загородных домов, коттеджей и дач сайдинг является практически незаменимым материалом для отделки. Он не только эстетично смотрится, но и отличается высокими защитными свойствами, надёжностью и доступной ценой. Например, отделка цоколя металлическим сайдингом поможет вам на десятилетия защитить фундамент вашего дома. А если вы хотитепридать дому аккуратный и элегантный вид, лучшим выбором будет обшивка дома виниловым сайдингом Деке.&nbsp;</p>\n\n<p>Сайдинг исключительно удобен в монтаже. Он собирается, как паззл, поэтому подходит для обшивки домов любого размера без предварительной подготовки. Сами работы не занимают много времени. Ещё один плюс такого решения &ndash; широкий выбор оттенков покрытия, с помощью чего вы сможете реализовать любые идеи.&nbsp;</p>\n\n<p>Бытует мнение, что варианты отделки сайдингом не отличаются оригинальностью, но мы готовы доказать обратное. При отделке дома этим покрытием можно использовать панели, которые искусно имитируют разные фактуры &ndash; дерево, камень или кирпич. В нашей компании вы можете заказать все виды и размеры сайдинга для обшивки дома по выгодным ценам.</p>\n\n<h2>Сайдинг для отделки балконов и лоджий</h2>\n\n<p><a href="/services/remont-i-obustroystvo-lodzhiy-balkonov">Обустройство балконов</a> &ndash; один из трендов последних лет. Ежегодно мы выполняем сотни таких заказов. Ещё недавно самым популярным решение была наружная <a href="/services/evrovagonka">обшивка балконов евровагонкой</a>. Сейчас так уже не делают, и для отделки используют более современные материалы, такие, как сайдинг.</p>\n\n<p>Чтобы вы могли наглядно представить, как изменится пространство вокруг вас после отделки, мы готовы продемонстрировать образцы сайдинга для обшивки дома и балкона. Мы подберём размер, цвет и цену этого материала для любого вашего проекта.</p>\n\n<p>Сайдинг удобен тем, что надёжно защищает стены, выдерживает перепады температур и высокую влажность. Если вы хоте заказать <a href="/services/uteplenie-balkonov-lodzhiy">утепление балкона</a>, то отделка сайдингом будет необходимой составляющей этой работы.</p>\n\n<p>Специалисты компании &laquo;Элитмонтаж&raquo; прошли необходимое обучение и наработали достаточный опыт, чтобы отделка балкона сайдингом всегда соответствовала вашим пожеланиям. При этом цены на нашу работу всегда доступны. На нашем сайте вы можете узнать базовые цены на услугу по наружной обшивке балкона сайдингом. Точная стоимость зависит от типа материала, размеров помещения и ряда других факторов.</p>\n\n<p>Мы можем гарантировать, что стоимость работ по обшивке сайдингом любых объектов будет выгодна для вас. Мы сделаем точный расчет работ, предложим скидки и поможем вам придать новый современный вид вашему дому, балкону или лоджии.</p>\n', '', '', '', '', 'services'),
(21, 1, 'Ремонт и отделка входных групп', '<p>Ремонт, регулировка, отделка входных групп и пластиковых дверей.&nbsp;</p>\n', '<h1>Ремонт, отделка и фурнитура для пластиковых дверей и входных групп</h1>\n\n<p>Двери и входные группы на основе алюминиевого или пвх профиля, так же, как и <a href="/">пластиковые окна в Новосибирске</a>, которые предлагает компания &laquo;Элитмонтаж&raquo;, предназначены для многолетнего использования. Срок их службы составляет десятки лет. Они выдерживают высокую нагрузку, но если не проводить регулярное техническое обслуживание, вам может понадобиться ремонт пластиковой двери.</p>\n\n<p>Специалисты сервисной службы нашей компании готовы помочь вам с ремонтом.</p>\n\n<p>Чаще всего, ремонт входных групп заключается в решении проблем с фурнитурой или устранении дефектов монтажа.</p>\n\n<h2>Проблемы, связанные с замком</h2>\n\n<p>Если вы заметили, что ручка и замок функционируют плохо, сначала мы проверим, нельзя ли обойтись настройкой фурнитуры и смазкой. В этом случае ремонт будет быстрым. Если же ручка не поворачивается вовсе, а замок заклинило, тогда придётся полностью заменить замок для пластиковой двери, чтобы она работала исправно. Такие поломки чаще всего связаны с механическим повреждением.</p>\n\n<h2>Проблемы, связанные с петлями</h2>\n\n<p>Если пластиковая дверь перестала плотно закрываться, вы чувствуете сквозняк, возможно, проблема в износе резинового уплотнителя. Если вы заметили, что дверь просела, скорее всего, потребуется заменить петли для пластиковой двери. Мы легко устраним эти проблемы.</p>\n\n<p>Кроме этого, мы оказываем следующие услуги:</p>\n\n<ul>\n	<li>Замена сэндвич-панели, стекла или стеклопакета;</li>\n	<li>Установка и регулировка доводчиков;</li>\n	<li>Установка ответных планок;</li>\n	<li>Другие услуги, связанные с ремонтом и регулировкой пластиковых деверей и входных групп.</li>\n</ul>\n\n<p>Чтобы входные группы служили как можно дольше и работали исправно, наши специалисты помогут с их техническим обслуживанием, в которое входит чистка и смазка фурнитуры, регулировка петель, замков и ручек, укрепление порогов и рам.</p>\n\n<p>А для того, чтобы они гармонично вписывались в интерьер помещения и фасад здания, вам будут полезные наши услуги по их отделке.</p>\n\n<p>Отделка входных групп требует большого опыта и мастерства специалистов, как и <a href="/services/otdelka-obshivka-balkonov">отделка балконов</a> или окон. Наши специалисты обладают необходимыми навыками для того, чтобы ваши двери не только прекрасно функционировали, но и отлично выглядели. Для этого мы подберём подходящую по цвету фурнитуру, предложим каширование пластика, тонировку стеклопакетов специальной плёнкой.&nbsp;</p>\n\n<p>Обращаясь к нам с любой проблемой, вы можете быть уверены, что мы предложим быстрое и оптимальное решение.</p>\n', '', '', '', '', 'services'),
(23, 1, 'Ремонт лоджий', '<p>Ремонт и обустройство балконов, лоджий - этапы, варианты ремонтных работ.&nbsp;</p>\n', '<h1>Ремонт лоджий и балконов и их обустройство</h1>\n\n<p>Из-за особенностей нашего климата лоджия &ndash; наименее обжитое помещение в большинстве квартир. Чаще всего ее отделкой занимаются в последнюю очередь.</p>\n\n<p>Иногда это откладывается на годы, и из-за многолетнего воздействия дождя, снега, перепадов температур и высокой влажности ремонт лоджий в Новосибирске становится настоящей спасательной операцией. Мы расскажем, какие проблемы способны решить наши специалисты, и как вы можете получить многофункциональную кладовую или дополнительную тёплую комнату.</p>\n\n<table cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/obustroystvo-balkona-i-lodzhii.jpg" style="width: 120px; height: 120px;" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/kompleksnyy-remont-balkona.jpg" style="width: 120px; height: 150px;" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/remont-balkona-vnutri.jpg" style="width: 120px; height: 90px;" /></td>\n			<td><img alt="" class="fancybox" rel="gallery1" src="/files/pictures/images/remont-lodzhii.jpg" style="width: 120px; height: 160px;" /></td>\n		</tr>\n	</tbody>\n</table>\n\n<div class="accordion">\n<h2>Замена рам</h2>\n\n<div>\n<table cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td>На многих лоджиях до сих пор установлены старые деревянные рамы. Со временем они деформируются, подвергаются воздействию бактерий и влаги. В этих случаях мы предлагаем <a href="/services/osteklenie-balkonov-i-lodzhiy">остекление лоджий</a> современными материалами, без чего дальнейшее обустройство помещения не будет иметь никакого смысла.\n\n			<p>&nbsp;</p>\n			У нас вы можете <a href="/">заказать пластиковые окна</a> или окна из алюминиевого профиля, в зависимости от желаемого результата. Многие клиенты заказывают замену оконного блока во время такого ремонта.\n\n			<p>&nbsp;</p>\n			</td>\n			<td>\n			<p>Помимо замены окон, вам будет необходима установка и регулировка пластиковой двери на балконе, идущей в составе блока. В отличие от деревянных, пластиковые двери не требуют покраски, лучше сохраняют тепло, ими удобней пользоваться и они отлично вписываются в современный интерьер.</p>\n\n			<div class="mark">Мы демонтируем старые конструкции, вынесем строительный мусор и выполним остекление в кратчайшие сроки. Сотрудничество с нами будет удобным, потому что вы получите полный комплекс услуг от производителя.</div>\n			</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>После замены окон мы можем предложить москитные сетки на балкон или лоджию для защиты от пыли, пуха и насекомых.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Устранение дефектов</h2>\n\n<div>\n<p>Жильцам старых домов может потребоваться большой комплекс работ, и даже полная реставрация балкона. В зависимости от проблемы, которую требуется решить в каждом конкретном случае, наш мастер по ремонту балконов предложит вам оптимальное решение.</p>\n\n<p>Сначала наши мастера оценивают состояние помещения, делают необходимые замеры, после чего приступают к решению проблемы. По мере необходимости производится <strong>ремонт или изготовление и установка кровли (крыши) или козырька балкона</strong> &mdash; такая услуга необходима жильцам верхних этажей, ведь, к сожалению, козырьки установлены далеко не во всех домах.</p>\n\n<p>Кроме этого, мы заменяем ограждение балконов, лоджий и террас из металла, если его состояние признано неудовлетворительным, или если того требует дизайнерское решение. В некоторых случаях может потребоваться установка перил, которую наши специалисты выполнят при необходимости &ndash; для большей надежности и удобства.</p>\n\n<div class="mark">Обращаем ваше внимание, что среди наших сотрудников есть специалисты, которые могут проводить сварочные работы, имеющие профессиональное оборудование &ndash; переносной инверторный сварочный аппарат.</div>\n\n<p>Мы готовы привести в порядок и сделать безопасным помещение любого размера. Нам по силам отремонтировать маленький балкон и большой современный, в каком бы состоянии они ни находились.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Обустройство</h2>\n\n<div>\n<p>Даже если помещение не имеет серьёзных дефектов и не требует реставрации, мы сможем предложить обустройство и оформление балконов и лоджий. В итоге вы получите дополнительное пространство, которое сможете использовать с комфортом.</p>\n\n<h3>Внешний вид</h3>\n\n<p>Когда люди задумываются о ремонте, отделка представляется им по-разному. Но внешний вид &ndash; это ещё не всё. При выборе материалов важно учитывать, насколько они будут защищены от влаги и перепадов температур. Если в ваши планы входит превращение присоединённого помещения в жилую комнату, ему потребуется обязательная паро- и гидро теплоизоляция. Тогда вы сможете использовать практически любые материалы для отделки.</p>\n\n<h3>Комфорт</h3>\n\n<p>Для создания комфортного температурного режима мы осуществляем <a href="/services/uteplenie-balkonov-lodzhiy">утепление балконов и лоджий</a> современными материалами, благодаря которым вы сможете использовать эти помещения круглый год.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Пол и стены</h2>\n\n<div>\n<table cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td>Как правило, после паро,гидро и теплоизоляции мы начинаем ремонт пола. В комплекс этих работ входит выравнивание, поднятие и стяжка пола на балконе. После чего монтируется основание, на которое укладывается фанера, линолеум, ламинат, напольная плитка и даже паркет, доска для пола.</td>\n			<td>\n			<div class="mark">Для отделки потолка и стен мы также сможем использовать любой материал по вашему желанию. В конце происходит установка пластикового порога или подоконника на балконе и помещение приобретает абсолютно новый вид!</div>\n			</td>\n		</tr>\n	</tbody>\n</table>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Зимний холодильник</h2>\n\n<div>\n<p>В некоторых случаях в квартирах предусмотрен так называемый зимний холодильник &ndash; небольшой шкаф, предназначенный для хранения продуктов в холодное время года. Ремонт холодильника на балконе &ndash; одна из наших услуг. Мы обшиваем стенки панелями, после чего устанавливаем пластиковые двери. Если вам кажется, что зимний холодильник устарел, мы докажем, что он может стать современной и удобной деталью вашего интерьера.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h2>Тонировка</h2>\n\n<div>\n<p>На этом наши услуги по обустройству не заканчиваются. Для желающих защититься от яркого солнечного света, ультрафиолета и любопытных взглядов будет интересна тонировка окон и лоджий.</p>\n\n<table cellpadding="1" cellspacing="1">\n	<tbody>\n		<tr>\n			<td>\n			<div class="mark">\n			<p>Для тонировки используется специальная плёнка, которая наклеивается внутри стеклопакета. Она не только придаёт окнам современный вид, но и отличается высокой надежностью: за время нашей практики не было случаев, чтобы тонировка балконов доставляла какие-то неудобства клиентам.</p>\n\n			<p>Плёнка не пузырится, не отклеивается, не деформируется под воздействием солнечных лучей.</p>\n			</div>\n			</td>\n			<td>Альтернативой тонировке могут выступить окна с цветными матовыми стёклами.\n			<p>&nbsp;</p>\n			Если вы не знаете, какое решение подойдёт вам лучше всего, консультация наших специалистов обязательно поможет вам определиться.\n\n			<p>&nbsp;</p>\n			</td>\n		</tr>\n	</tbody>\n</table>\n</div>\n</div>\n\n<h2>Стоимость обустройства и ремонта балкона</h2>\n\n<p>Как видите, вы можете обратиться к нам за решением практически любой задачи. При оформлении заказа мы внимательно оцениваем особенности каждого заказа, поэтому цена на ремонт балкона или лоджии под ключ всегда определяется индивидуально.</p>\n\n<p>Вы можете быть уверены, что вам не придётся переплачивать, поскольку мы обосновываем необходимость каждого вида работ и предлагаем услуги без наценок. Специалисты компании &laquo;Элитмонтаж&raquo; всегда готовы помочь сделать ваш дом надёжным и удобным.</p>\n\n<p>&nbsp;</p>\n', '', '', '', '', 'services');
INSERT INTO `contents_descriptions` (`content_id`, `lang_id`, `content_title`, `content_teaser`, `content_body`, `content_menu`, `content_var_field1`, `content_var_field2`, `content_text_field`, `module`) VALUES
(24, 1, 'Утепление балконов', '<p>Способы утпления балконов и лоджий, теплоизолирующие материалы и их применение.&nbsp;</p>\n', '<h1>Утепление лоджий и балконов</h1>\n\n<p>Расширить площадь квартиры &ndash; мечта многих. И сделать это возможно за счет повышения функциональности балкона. Но как сделать его по-настоящему тёплым, особенно с учетом непростых климатических условий нашего города? Мы ответим на этот вопрос.</p>\n\n<h2>Предотвращение потерь тепла</h2>\n\n<p>Вы должны знать, что около 80% тепла удерживают оконные конструкции. Поэтому <a href="/">пластиковые окна в Новосибирске</a> нужно выбирать особенно тщательно, иначе работа не будет иметь практически никакого смысла.</p>\n\n<p>Теплопотери на объектах, которые обустраивают специалисты нашей компании, минимальны. После того, как наши специалисты выполнили остекление балкона или лоджии, можно приступить к работе по <a href="/services/otdelka-obshivka-balkonov">внутренней отделке</a>.</p>\n\n<h2>Технологии утепления</h2>\n\n<p>Основными показателями, по которым мы отбираем лучшие материалы для утепления парапета, стен и потолка на лоджии и балконе, являются высокое качество шумо-, гидро- и теплоизоляции.</p>\n\n<p>Сегодня выбор подходящего сырья довольно велик, поэтому у нас есть возможность предлагать клиентам проверенные и выгодные решения. Самыми популярными материалами являются пенополиуретан, минеральный утеплитель (минеральня вата) и пенополистирол.</p>\n\n<div class="accordion">\n<h3>Минеральный утеплитель (вата)</h3>\n\n<div>\n<p>Самый классический вид утеплителя. Минеральная вата относится к мягким утеплителям. Она выпускается в плитах, матах или рулонах, удобная фасовка позволяет выполнить работы быстро и просто.</p>\n\n<p>Минеральная вата дает хорошую тепло- и звукоизоляцию. Она абсолютно пожаробезопасна, что позволяет ее использовать на любых объектах. Цены на утепление лоджии и балкона под ключ с использованием минеральной ваты примерно сопоставимы с другими утеплителями, и для того, чтобы определить, какой материал имеет смысл использовать в вашем случае, рекомендуем посоветоваться со специалистами.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h3>Пенополистирол</h3>\n\n<div>\n<p>Более современное решение &mdash; это утепление лоджий и балконов Пеноплексом и Пенофолом, то есть пенополистриролами. Они обладают отличными гидроизоляционными свойствами, не требуют особой обработки, занимают немного места и служат около 15 лет.</p>\n\n<p><strong>Пеноплекс</strong> производится в виде тонких плиток и применяется для того, чтобы сохранить тепло, не выпустить его наружу. Он обладает высокими гидроизоляционными свойствами, поэтому может применяться даже в помещениях с очень высокой влажностью.</p>\n\n<p>Утепление пола на лоджии и балконе Пеноплексом мы выполняем по той же технологии. Толщина такого покрытия составляет не более 100 мм.</p>\n\n<p><strong>Пенофол</strong> выпускается в рулонах, обладает отражающими свойствами. Его толщина составляет всего 25 мм. Он накладывается поверх Пеноплекса, после чего даже холодные внешние стены будут надёжно защищены. Первый слой будет удерживать тепло внутри помещения, а второй &mdash; отражать его.</p>\n\n<p>Вы получите не только непромерзающие стены и потолок, но и тёплый пол на балконе и лоджии без лишних затрат на дополнительную обработку. К тому же он не очень дорогой. Если сравнить стоимость утепления балконов и лоджий минеральной ватой или пенополистиролом, то использование последнего получится даже выгоднее из-за более долгого срока службы и высокой надёжности.</p>\n</div>\n</div>\n\n<div class="accordion">\n<h3>Пенополиуретан</h3>\n\n<div>\n<p>Для клиентов, которым важна скорость отделки, мы можем предложить пенополиуретан. Он распыляется достаточно тонким слоем на поверхности. Работы занимают всего несколько часов; дополнительная гидро- и пароизоляция не требуется.</p>\n\n<p>Стоимость утепления лоджии пенополиуретаном выше, что неудивительно, учитывая его высокое качество и надежность. К тому же с помощью ППУ можно значительно сэкономить расходы на отопление, благодаря его надёжным теплоизолирующим свойствам. Его срок службы составляет от 30 до 50 лет.</p>\n\n<p>Все виды утеплителей, которые мы предлагаем, можно использовать в домах разного типа.</p>\n</div>\n</div>\n\n<h2>Стоимость тёплой лоджии и балкона под ключ</h2>\n\n<p>Пред тем как приступить к обустройству нежилого помещения, необходимо произвести точные замеры и оценить его состояние. Цена на утеплитель для пола и стен балкона или лоджии может значительно различаться, и итоговая сумма всегда рассчитывается индивидуально.</p>\n\n<p>Здесь учитывается количество тёплых и холодных стен, их состояние и материал, необходимость установки дополнительных конструкций, количество необходимой фурнитуры и материалов.</p>\n\n<p>По вашему желанию в стоимость заказа может быть включена <a href="/services/otdelka-obshivka-balkonov">отделка и обшивка балконов и лоджий</a>, чтобы вы получили их полностью готовыми к использованию.</p>\n\n<p>Получить бесплатную консультацию специалистов вы всегда можете, связавшись с нами.</p>\n', '', '', '', '', 'services'),
(15, 2, 'About us', '<p>\n	 <span style="background-color: initial;">The Karachinsky Source company - the largest Russian manufacturing company of mineral water Karachinskaya, series of the sweet aerated drinks on its basis and drinking water Assol.</span>\n</p>', '<p>\n <span style="background-color: initial;"> the Karachinsky Source Company - the largest Russian manufacturing company of mineral water Karachinskaya, series of sweet carbonated drinks on its basis and drinking water Assol. </span>\n</p><p>\n       By results of market researches, the Karachinsky Source company takes the leading position in the market of sparkling water since 2011.\n</p><table><tbody><tr> <th>\n     No.\n </th> <th>\n     Brand\n </th> <th>\n     2011\n </th> <th>\n     2012\n </th> <th>\n     2013\n </th></tr><tr> <td>\n     1\n </td> <td>\n     Karachinskaya (Karachinsky Source)\n </td> <td>\n     192,2\n </td> <td>\n     213,5\n </td> <td>\n     194,9\n </td></tr><tr> <td>\n     2\n </td> <td>\n     Yessentuki (Some producers)\n </td> <td>\n     178,1\n </td> <td>\n     163,8\n </td> <td>\n     160,7\n </td></tr><tr> <td>\n     3\n </td> <td>\n     Bonaqua (the Cook – Cola)\n </td> <td>\n     151,7\n </td> <td>\n     134,5\n </td> <td>\n     117,9\n </td></tr><tr> <td>\n     4\n </td> <td>\n     Akwa Minerale (Pepsiko)\n </td> <td>\n     109,8\n </td> <td>\n     99\n </td> <td>\n     93,3\n </td></tr><tr> <td>\n     5\n </td> <td>\n     Novotersky curative (Kaminvoda)\n </td> <td>\n     72,5\n </td> <td>\n     71,2\n </td> <td>\n     79,3\n </td></tr><tr> <td>\n     6\n </td> <td>\n     Hang Kul (Ayan)\n </td> <td>\n     63,5\n </td> <td>\n     67,1\n </td> <td>\n     61,6\n </td></tr><tr> <td>\n     7\n </td> <td>\n     Edelweiss (IDS Borjomi)\n </td> <td>\n     63,5\n </td> <td>\n     61,3\n </td> <td>\n     52\n </td></tr><tr> <td>\n     8\n </td> <td>\n     Mercury (Mercury)\n </td> <td>\n     63,4\n </td> <td>\n     62,5\n </td> <td>\n     51,8\n </td></tr><tr> <td>\n     9\n </td> <td>\n     Lipetsk Pump room (Progress)\n </td> <td>\n     58,6\n </td> <td>\n     55,8\n </td> <td>\n     51,5\n </td></tr><tr> <td>\n     10\n </td> <td>\n     Narzan (Narzan)\n </td> <td>\n     41,5\n </td> <td>\n     48,2\n </td> <td>\n     47,3\n </td></tr></tbody></table><p>\n <img src="/files/1413775268_unnamed.jpg">\n</p>', '', '', '', '', 'pages'),
(91, 1, 'Предполагается работа лектория', '<p>С 18 по 20 мая на базе Амурского государственного университета соберутся порядка 700 магистрантов и аспирантов, а также молодых ученых и специалистов со всей России. Всех их объединит «Космофест Восточный» – образовательное пространство, где созданы все условия для формирования молодежных профессиональных сообществ в ракетно-космической отрасли</p>', '<p>С 18 по 20 мая на базе Амурского государственного университета соберутся порядка 700 магистрантов и аспирантов, а также молодых ученых и специалистов со всей России. Всех их объединит «Космофест Восточный» – образовательное пространство, где созданы все условия для формирования молодежных профессиональных сообществ в ракетно-космической отрасли.</p><p>Программа «Космофеста» предполагает мастер-классы по ракетомоделированию и спутникостроению, организации поисково-спасательной службы в пилотируемой космонавтике и системам обеспечения жизнедеятельности космонавтов, профориентационная площадка «Карьерная траектория» и многое другое.</p><p>В рамках панельной дискуссии о развитии ракетно-космической отрасли России с участием экспертов и приглашенных гостей пройдет также молодежная сессия, которая затронет актуальные вопросы о перспективных направлениях развития отечественной космонавтики в Дальневосточном федеральном округе. Состоится встреча проектной группы «Комплексное развитие космического кластера на Востоке России».</p><p>Предполагается работа лектория «Открытый космос»: лекции и выступления космонавтов, представителей космической отрасли, научной сферы и работа космического киноклуба, финальная битва «Юных прогрессоров».</p><p>На фестивале также будет работать выставка инновационных проектов студентов вузов в области космических технологий.</p>', '', '', '', '', 'news'),
(14, 1, '', '', '', '', '', '', '', 'modulinfo'),
(28, 1, 'Блок информации на главной​', '<h2></h2>\n<p>\n	<span style="font-size: 16px;">Изобретенная в России технология UVLEDпечати позволяет наносить изображения фотографического качества на любые виды материалов: МДФ, ЛДСП, стекло, зеркало, пластик, обои, кафельная плитка… в основном для декорирования интерьеров домов и офисов. Изготовления фартуков, панно на кухню. Основными преимуществами UVпечати являются экологичность готовой продукции, возможность нанесения любых изображений с соблюдением цветопередачи. Готовая продукция абсолютно безопасна для окружающей среды и здоровья человека – а это принципиально важно для продукции, применяемой для декорирования дома или офиса. Мы предоставляем изображения высокого качества для печати, их более 10 000 на любую тематику.</span>\n</p>', '', '', '', '', '', 'infoblock'),
(15, 1, '', '', '', '', '', '', '', 'modulinfo'),
(230, 1, 'Корпусная мебель', '', '', '', '', '', '', 'categories'),
(32, 1, 'Адресный блок в нижней части сайта', '<p>\n	Краткая контактная информация\n</p>', '', '', '', '', '', 'infoblock'),
(33, 1, 'Преимущество на главной 1', '<p>\n	 <img src="/files/1493741897_001-orange.png" alt="" style="float: left; margin: 0px 10px 10px 0px;">\n</p>\n<p>\n	<strong style="background-color: initial;">Высокое качество товаров и услуг</strong>\n</p>', '', '', '', '', '', 'infoblock'),
(34, 1, 'Преимущество на главной 2', '<p>\n	 <img src="/files/1493741934_002-orange.png" alt="" style="float: left; margin: 0px 10px 10px 0px;">\n</p>\n<p>\n	<strong style="background-color: initial;">Наша компания на строительном рынке более 15 лет</strong>\n</p>', '', '', '', '', '', 'infoblock'),
(35, 1, 'Преимущество на главной 3', '<p>\n	 <img src="/files/1493741956_003-orange.png" alt="" style="float: left; margin: 0px 10px 10px 0px;">\n</p>\n<p>\n	<strong style="background-color: initial;">Разумная ценовая политика</strong>\n</p>', '', '', '', '', '', 'infoblock'),
(235, 1, 'Сварочные материалы', '', '', '', '', '', '', 'categories'),
(236, 1, 'Средства защиты и аксессуары', '', '', '', '', '', '', 'categories'),
(237, 1, 'Вспомогательные материалы', '', '', '', '', '', '', 'categories'),
(180, 1, 'Каталог продукции', '', '', '', '', '', '', 'menu'),
(181, 1, 'Специальные предложения', '', '', '', '', '', '', 'menu'),
(238, 1, 'Маски', '', '', '', '', '', '', 'categories'),
(239, 1, 'Полноразмерные', '', '', '', '', '', '', 'categories'),
(86, 1, 'Маска защитная', '<p>\n	Маска защитная применяется в строительстве, ремонтных работах\n</p>', '<p>\n	<span style="background-color: initial;">Маска защитная применяется в строительстве, ремонтных работах </span><span style="background-color: initial;">Маска защитная применяется в строительстве, ремонтных работах</span>\n</p>\n<p>\n	Маска защитная применяется в строительстве, ремонтных работах.\n</p>', '', '', '', '', 'catalog'),
(6, 1, 'Весенняя распродажа электродов', '<p>\n	Краткое описание акции\n</p>', '<p>\n	Подробное описание акции\n</p>', '', '', '', '', 'actions'),
(7, 1, 'Скидка 20% на весь ассортимент к дню строителя', '<p>\n	Анонс акции\n</p>', '<p>\n	Подробное описание акции\n</p>', '', '', '', '', 'actions'),
(169, 1, 'О нас', '', '', '', '', '', '', 'menu'),
(170, 1, 'Контакты', '', '', '', '', '', '', 'menu'),
(234, 1, 'Абразивы и инструменты', '', '', '', '', '', '', 'categories'),
(233, 1, 'Газосварочное оборудование', '', '', '', '', '', '', 'categories'),
(232, 1, 'Сварочное оборудование', '', '', '', '', '', '', 'categories'),
(179, 1, 'Главная', '', '', '', '', '', '', 'menu');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_doimages`
--

CREATE TABLE IF NOT EXISTS `contents_doimages` (
  `content_id` int(10) DEFAULT NULL,
  `file_id` int(10) DEFAULT NULL,
  `delta` int(5) DEFAULT NULL,
  `is_image` int(1) DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contents_doimages`
--

INSERT INTO `contents_doimages` (`content_id`, `file_id`, `delta`, `is_image`, `module`) VALUES
(174, 3, 0, 1, 'categories');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_fields`
--

CREATE TABLE IF NOT EXISTS `contents_fields` (
  `content_id` int(10) DEFAULT NULL,
  `field_id` int(10) DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contents_fields`
--

INSERT INTO `contents_fields` (`content_id`, `field_id`, `module`) VALUES
(167, 15, 'categories'),
(167, 14, 'categories'),
(165, 11, 'categories');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_files`
--

CREATE TABLE IF NOT EXISTS `contents_files` (
  `file_id` int(5) NOT NULL,
  `content_id` int(5) NOT NULL,
  `delta` int(5) NOT NULL DEFAULT '0',
  `is_image` int(1) NOT NULL DEFAULT '0',
  `module` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contents_files`
--

INSERT INTO `contents_files` (`file_id`, `content_id`, `delta`, `is_image`, `module`) VALUES
(4351, 13, 0, 1, 'articles'),
(4352, 14, 0, 1, 'articles'),
(4353, 15, 0, 1, 'articles'),
(4354, 16, 0, 1, 'articles'),
(4360, 19, 0, 1, 'articles'),
(4372, 29, 0, 1, 'articles'),
(4606, 13, 1, 0, 'services'),
(4589, 10, 1, 0, 'services'),
(4784, 8, 1, 0, 'services'),
(4785, 9, 1, 0, 'services'),
(4681, 12, 1, 1, 'services'),
(4682, 12, 2, 1, 'services'),
(4683, 12, 3, 1, 'services'),
(4743, 7, 0, 0, 'services'),
(5044, 90, 0, 1, 'news'),
(5045, 91, 0, 1, 'news'),
(5373, 232, 1, 1, 'categories'),
(5371, 7, 1, 1, 'banners'),
(5372, 7, 2, 1, 'banners'),
(5374, 233, 1, 1, 'categories'),
(5375, 234, 1, 1, 'categories'),
(5376, 235, 1, 1, 'categories'),
(5377, 236, 1, 1, 'categories'),
(5378, 237, 1, 1, 'categories'),
(5379, 86, 0, 1, 'catalog'),
(5380, 238, 1, 1, 'categories'),
(5381, 239, 1, 1, 'categories'),
(5382, 6, 0, 1, 'actions'),
(5383, 7, 0, 1, 'actions');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_seo`
--

CREATE TABLE IF NOT EXISTS `contents_seo` (
  `content_id` int(10) DEFAULT NULL,
  `seo_id` int(10) DEFAULT NULL,
  `module` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contents_seo`
--

INSERT INTO `contents_seo` (`content_id`, `seo_id`, `module`) VALUES
(22, 504, 'services'),
(15, 495, 'services'),
(1, 2146, 'siteinfo'),
(7, 728, 'services'),
(8, 727, 'services'),
(9, 739, 'services'),
(10, 738, 'services'),
(11, 639, 'services'),
(12, 715, 'services'),
(13, 557, 'services'),
(16, 498, 'services'),
(17, 529, 'services'),
(18, 527, 'services'),
(19, 642, 'services'),
(20, 711, 'services'),
(21, 505, 'services'),
(23, 497, 'services'),
(24, 496, 'services'),
(15, 2160, 'pages'),
(7, 1750, 'documents'),
(3, 2159, 'pages'),
(14, 1705, 'modulinfo'),
(15, 1738, 'modulinfo'),
(8, 1751, 'documents'),
(9, 1752, 'documents'),
(10, 1753, 'documents'),
(11, 1754, 'documents'),
(12, 1755, 'documents'),
(16, 1757, 'modulinfo'),
(17, 1758, 'modulinfo'),
(90, 1760, 'news'),
(91, 1761, 'news'),
(233, 2149, 'categories'),
(230, 2088, 'categories'),
(232, 2148, 'categories'),
(234, 2150, 'categories'),
(235, 2151, 'categories'),
(236, 2152, 'categories'),
(237, 2153, 'categories'),
(86, 2154, 'catalog'),
(238, 2155, 'categories'),
(239, 2156, 'categories'),
(6, 2157, 'actions'),
(7, 2158, 'actions');

-- --------------------------------------------------------

--
-- Структура таблицы `doctors`
--

CREATE TABLE IF NOT EXISTS `doctors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `alias` varchar(250) DEFAULT NULL,
  `menu` varchar(64) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Структура таблицы `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `date` varchar(250) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL,
  `alias` varchar(250) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Структура таблицы `doimages`
--

CREATE TABLE IF NOT EXISTS `doimages` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `filename` varchar(64) DEFAULT NULL,
  `filepathname` varchar(255) DEFAULT NULL,
  `filesize` int(10) DEFAULT NULL,
  `fileurl` varchar(255) DEFAULT NULL,
  `filetype` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `doimages`
--

INSERT INTO `doimages` (`id`, `filename`, `filepathname`, `filesize`, `fileurl`, `filetype`) VALUES
(1, '1419843163_dsc0518.jpg', '1419843163_dsc0518.jpg', 490217, 'http://colibri.loc/files/doimages/1419843163_dsc0518.jpg', 'image/jpeg'),
(2, '1419843813_dsc0535.jpg', '1419843813_dsc0535.jpg', 501584, 'http://colibri.loc/files/doimages/1419843813_dsc0535.jpg', 'image/jpeg'),
(3, '1419844205_dsc0518.jpg', '1419844205_dsc0518.jpg', 490217, 'http://colibri.loc/files/doimages/1419844205_dsc0518.jpg', 'image/jpeg'),
(4, '1419844206_dsc0535.jpg', '1419844206_dsc0535.jpg', 501584, 'http://colibri.loc/files/doimages/1419844206_dsc0535.jpg', 'image/jpeg');

-- --------------------------------------------------------

--
-- Структура таблицы `doimages_description`
--

CREATE TABLE IF NOT EXISTS `doimages_description` (
  `file_id` int(10) DEFAULT NULL,
  `lang_id` int(3) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `title` text,
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `content_id` int(5) DEFAULT NULL,
  `parent_id` int(5) DEFAULT NULL,
  `group_id` int(3) DEFAULT NULL,
  `doctor_id` int(5) NOT NULL,
  `date` varchar(64) DEFAULT NULL,
  `contact` varchar(255) NOT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Структура таблицы `fields`
--

CREATE TABLE IF NOT EXISTS `fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `lang_id` int(10) DEFAULT NULL,
  `field0` text,
  `field1` text,
  `field2` text,
  `field3` text,
  `field4` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `fields`
--

INSERT INTO `fields` (`id`, `lang_id`, `field0`, `field1`, `field2`, `field3`, `field4`) VALUES
(14, 1, '//www.youtube.com/embed/WLVXHYP4HJ0', 'Планируйте здоровье', NULL, NULL, NULL),
(15, 1, '//www.youtube.com/embed/wzkO1bmRLig', '40 лет делимся лучшим!', NULL, NULL, NULL),
(11, 1, '//www.youtube.com/embed/Jc9IhOvzlvQ', 'Яркий вкус здоровья', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `filename` varchar(64) NOT NULL,
  `filepathname` varchar(250) NOT NULL,
  `filesize` int(10) NOT NULL,
  `fileurl` varchar(250) NOT NULL,
  `filetype` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5384 ;

--
-- Дамп данных таблицы `files`
--

INSERT INTO `files` (`id`, `filename`, `filepathname`, `filesize`, `fileurl`, `filetype`) VALUES
(4351, '636131419.jpg', '636131419.jpg', 33882, 'http://happysecret.ru/files/636131419.jpg', 'image/jpeg'),
(4352, '632281825.jpg', '632281825.jpg', 4959, 'http://happysecret.ru/files/632281825.jpg', 'image/jpeg'),
(4353, '182121426.jpg', '182121426.jpg', 5045, 'http://www.happysecret.ru/files/182121426.jpg', 'image/jpeg'),
(4354, '7161135.jpg', '7161135.jpg', 4959, 'http://www.happysecret.ru/files/7161135.jpg', 'image/jpeg'),
(4360, '28103498.jpg', '28103498.jpg', 73503, 'http://www.happysecret.ru/files/28103498.jpg', 'image/jpeg'),
(4372, '31722423.jpg', '31722423.jpg', 6246, 'http://www.happysecret.ru/files/31722423.jpg', 'image/jpeg'),
(4606, '1388230896_prices.xlsx', '1388230896_prices.xlsx', 54117, 'http://elit-montag.ru/files/files/1388230896_prices.xlsx', ''),
(4492, '1411181233.jpeg', '1411181233.jpeg', 7718, 'http://elix.loc/files/1411181233.jpeg', 'image/jpeg'),
(4493, '9134113.jpeg', '9134113.jpeg', 6177, 'http://elix.loc/files/9134113.jpeg', 'image/jpeg'),
(4491, '81229310.jpeg', '81229310.jpeg', 39379, 'http://elix.loc/files/81229310.jpeg', 'image/jpeg'),
(4589, '1387887073_preyskurant-cen.docx', '1387887073_preyskurant-cen.docx', 16829, 'http://www.elitmontazh.vadimdesign.ru/files/files/1387887073_preyskurant-cen.docx', ''),
(4569, 'b1.png', 'b1.png', 18249, 'http://okna.loc/files/b1.png', 'image/png'),
(4743, '1391281700_prices.xlsx', '1391281700_prices.xlsx', 54117, 'http://elit-montag.ru/files/files/1391281700_prices.xlsx', ''),
(4681, '1391076590_osteklenie-balkona.jpg', '1391076590_osteklenie-balkona.jpg', 87808, 'http://elit-montag.ru/files/1391076590_osteklenie-balkona.jpg', 'image/jpeg'),
(4682, '1391076590_osteklenie-balkona1.jpg', '1391076590_osteklenie-balkona1.jpg', 108611, 'http://elit-montag.ru/files/1391076590_osteklenie-balkona1.jpg', 'image/jpeg'),
(4784, '1392007557_prices.xlsx', '1392007557_prices.xlsx', 54117, 'http://elit-montag.ru/files/files/1392007557_prices.xlsx', ''),
(4785, '1392011387_preyskurant-cen.docx', '1392011387_preyskurant-cen.docx', 16829, 'http://elit-montag.ru/files/files/1392011387_preyskurant-cen.docx', ''),
(4683, '1391076590_osteklenie-balkona2.jpg', '1391076590_osteklenie-balkona2.jpg', 89829, 'http://elit-montag.ru/files/1391076590_osteklenie-balkona2.jpg', 'image/jpeg'),
(5044, '1463517870_10419138cc3327fa.jpg', '1463517870_10419138cc3327fa.jpg', 187057, 'http://molodezhka.loc/files/1463517870_10419138cc3327fa.jpg', 'image/jpeg'),
(5045, '1463517944_a0a8766e263dd4ba9ab19cc2e0a1754b56ae21b4.jpg', '1463517944_a0a8766e263dd4ba9ab19cc2e0a1754b56ae21b4.jpg', 93600, 'http://molodezhka.loc/files/1463517944_a0a8766e263dd4ba9ab19cc2e0a1754b56ae21b4.jpg', 'image/jpeg'),
(5375, '1493441378_c9be1f4b1f00a75dc4a4855522c17fc2.jpg', '1493441378_c9be1f4b1f00a75dc4a4855522c17fc2.jpg', 130126, 'http://svarka.loc/files/1493441378_c9be1f4b1f00a75dc4a4855522c17fc2.jpg', 'image/jpeg'),
(5373, '1493441070_d05dbf10020f1f6d5d1b3bc4cefad614.jpg', '1493441070_d05dbf10020f1f6d5d1b3bc4cefad614.jpg', 282131, 'http://svarka.loc/files/1493441070_d05dbf10020f1f6d5d1b3bc4cefad614.jpg', 'image/jpeg'),
(5374, '1493441133_a4beb78e58994197b60b858d9c13e4ec.jpg', '1493441133_a4beb78e58994197b60b858d9c13e4ec.jpg', 42400, 'http://svarka.loc/files/1493441133_a4beb78e58994197b60b858d9c13e4ec.jpg', 'image/jpeg'),
(5371, '1492798172_8d9ceba693b22e04d1512da916372914.jpg', '1492798172_8d9ceba693b22e04d1512da916372914.jpg', 156934, 'http://svarka.loc/files/1492798172_8d9ceba693b22e04d1512da916372914.jpg', 'image/jpeg'),
(5372, '1492798172_12847028516ef2e0c647db5923e7d7d5.jpg', '1492798172_12847028516ef2e0c647db5923e7d7d5.jpg', 210591, 'http://svarka.loc/files/1492798172_12847028516ef2e0c647db5923e7d7d5.jpg', 'image/jpeg'),
(5376, '1493441419_70951d20aa23607e34184b798a6e0535.jpeg', '1493441419_70951d20aa23607e34184b798a6e0535.jpeg', 10245, 'http://svarka.loc/files/1493441419_70951d20aa23607e34184b798a6e0535.jpeg', 'image/jpeg'),
(5377, '1493441437_12e730c1f82d595c8abf4ef317061e8e.jpg', '1493441437_12e730c1f82d595c8abf4ef317061e8e.jpg', 39889, 'http://svarka.loc/files/1493441437_12e730c1f82d595c8abf4ef317061e8e.jpg', 'image/jpeg'),
(5378, '1493441451_c74c2e6635384b02d090e6176612b86d.jpg', '1493441451_c74c2e6635384b02d090e6176612b86d.jpg', 29214, 'http://svarka.loc/files/1493441451_c74c2e6635384b02d090e6176612b86d.jpg', 'image/jpeg'),
(5379, '1493738571_12e730c1f82d595c8abf4ef317061e8e.jpg', '1493738571_12e730c1f82d595c8abf4ef317061e8e.jpg', 39889, 'http://svarka.loc/files/1493738571_12e730c1f82d595c8abf4ef317061e8e.jpg', 'image/jpeg'),
(5380, '1493739386_12e730c1f82d595c8abf4ef317061e8e.jpg', '1493739386_12e730c1f82d595c8abf4ef317061e8e.jpg', 39889, 'http://svarka.loc/files/1493739386_12e730c1f82d595c8abf4ef317061e8e.jpg', 'image/jpeg'),
(5381, '1493739396_12e730c1f82d595c8abf4ef317061e8e.jpg', '1493739396_12e730c1f82d595c8abf4ef317061e8e.jpg', 39889, 'http://svarka.loc/files/1493739396_12e730c1f82d595c8abf4ef317061e8e.jpg', 'image/jpeg'),
(5382, '1493739515_svetodiodnye-girlyandy-shariki-2.jpg', '1493739515_svetodiodnye-girlyandy-shariki-2.jpg', 46872, 'http://svarka.loc/files/1493739515_svetodiodnye-girlyandy-shariki-2.jpg', 'image/jpeg'),
(5383, '1493739786_transport-1.jpg', '1493739786_transport-1.jpg', 64460, 'http://svarka.loc/files/1493739786_transport-1.jpg', 'image/jpeg');

-- --------------------------------------------------------

--
-- Структура таблицы `files_description`
--

CREATE TABLE IF NOT EXISTS `files_description` (
  `file_id` int(10) DEFAULT NULL,
  `lang_id` int(3) NOT NULL DEFAULT '1',
  `link` varchar(255) NOT NULL,
  `title` text,
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `files_description`
--

INSERT INTO `files_description` (`file_id`, `lang_id`, `link`, `title`, `description`) VALUES
(4601, 1, '/services/ceny-na-osteklenie-balkonov-i-lodzhiy', '', ''),
(4607, 1, '/services/ceny-na-osteklenie-balkonov-i-lodzhiy#price', '', ''),
(4589, 1, '', 'Прейскурант цен', ''),
(4606, 1, '', 'Прейскурант цен', ''),
(4743, 1, '', 'Прейскурант цен', ''),
(4927, 2, '', '', ''),
(4681, 1, '', '', ''),
(4682, 1, '', '', ''),
(4683, 1, '', '', ''),
(4770, 1, '', '', ''),
(4771, 1, '', '', ''),
(4769, 1, '', '', ''),
(4768, 1, 'алт2', 'тайтл2', ''),
(4772, 1, '', '', ''),
(4773, 1, '', '', ''),
(4774, 1, '', '', ''),
(4775, 1, '', '', ''),
(4785, 1, '', 'Прейскурант цен', ''),
(4784, 1, '', 'Прейскурант цен', ''),
(4925, 1, 'http://www.okarachi.ru/', '', ''),
(4981, 1, '', '', ''),
(4925, 2, '', '', ''),
(4980, 1, '', '', ''),
(4927, 1, '', '', ''),
(4924, 2, '', '', ''),
(4924, 1, 'http://buhta-laz.ru/', '', ''),
(4961, 1, '', '', ''),
(4984, 1, '', '', ''),
(4807, 1, '', 'Минеральные воды России 1996', ''),
(4807, 2, '', '', ''),
(4808, 1, '', 'Международный конгресс по курортологии 1996', ''),
(4808, 2, '', '', ''),
(4809, 1, '', 'Сибирская ярмарка 1996', ''),
(4809, 2, '', '', ''),
(4810, 1, '', 'Международная выставка «ПродУрал-97»', ''),
(4810, 2, '', '', ''),
(4811, 1, '', 'International Water Industry Exhibition 1997', ''),
(4811, 2, '', '', ''),
(4812, 1, '', 'Вода - международная специализированная выставка 1997', ''),
(4812, 2, '', '', ''),
(4813, 1, '', 'Water Technology &amp; Environment 1997', ''),
(4813, 2, '', '', ''),
(4814, 1, '', 'Международная выставка-ярмарка «Пивоиндустрия-97»', ''),
(4814, 2, '', '', ''),
(4815, 1, '', 'Международный конкурс винодельческой, ликеро-водочной и безалкогольной продукции «Интердринк-97', ''),
(4815, 2, '', '', ''),
(4816, 1, '', 'Международная выставка-ярмарка «Агрпродсельмаш-97»', ''),
(4816, 2, '', '', ''),
(4817, 1, '', 'Международная выставка винодельческой, ликеро-водочной и безалкогольной продукции «Интердринк-98»', ''),
(4817, 2, '', '', ''),
(4818, 1, '', 'Международная выставка-ярмарка «Пивоиндустрия-98»', ''),
(4818, 2, '', '', ''),
(4819, 1, '', 'Выставка «Агропродсельмаш-98»', ''),
(4819, 2, '', '', ''),
(4820, 1, '', 'SIAL-98', ''),
(4820, 2, '', '', ''),
(4821, 1, '', 'SIAL-98', ''),
(4821, 2, '', '', ''),
(4822, 1, '', 'Международный конкурс винодельческой, ликеро-водочной и безалкогольной продукции «Интердринк-98»', ''),
(4822, 2, '', '', ''),
(4823, 1, '', 'Международная выставка-ярмарка «Пиво» 1998', ''),
(4823, 2, '', '', ''),
(4824, 1, '', 'International Exhibition «Arab water-98»', ''),
(4824, 2, '', '', ''),
(4825, 1, '', 'Международная выставка водных технологий «Каир-98»', ''),
(4825, 2, '', '', ''),
(4826, 1, '', 'Международный профессиональный конкурс напитков и минеральных вод 1998', ''),
(4826, 2, '', '', ''),
(4827, 1, '', 'Международная специализированная выставка «Санкт-Петергбурский пивной аукцион-98»', ''),
(4827, 2, '', '', ''),
(4828, 1, '', 'Всемирная выставка продуктов питания, напитков и минеральных вод 1999', ''),
(4828, 2, '', '', ''),
(4829, 1, '', 'Всемирная выставка продуктов питания, напитков и минеральных вод 1999', ''),
(4829, 2, '', '', ''),
(4830, 1, '', 'Кузнецкая ярмарка 1999', ''),
(4830, 2, '', '', ''),
(4831, 1, '', 'Международный профессиональный конкурс напитков и минеральных вод 1999', ''),
(4831, 2, '', '', ''),
(4832, 1, '', 'Выставка «Пивоиндустрия-99»', ''),
(4832, 2, '', '', ''),
(4833, 1, '', 'Конкурс «Пивная ярмарка Сибири-99»', ''),
(4833, 2, '', '', ''),
(4834, 1, '', 'Кузбасская ярмарка 1999', ''),
(4834, 2, '', '', ''),
(4835, 1, '', 'Выставка-ярмарка «Сибирская ярмарка» 1999', ''),
(4835, 2, '', '', ''),
(4836, 1, '', 'Выставка «Омскпродопт-99»', ''),
(4836, 2, '', '', ''),
(4837, 1, '', 'Международный конкурс «Интердринк» 1999', ''),
(4837, 2, '', '', ''),
(4838, 1, '', 'Международный профессиональный конкурс напитки и технологии производства 2000', ''),
(4838, 2, '', '', ''),
(4839, 1, '', 'Конкурс «Медаль Алтайской ярмарки» 2000', ''),
(4839, 2, '', '', ''),
(4840, 1, '', 'Omain International Exhibition 2000', ''),
(4840, 2, '', '', ''),
(4841, 1, '', 'Omain International Exhibition 2000', ''),
(4841, 2, '', '', ''),
(4842, 1, '', 'Кузнецкая ярмарка 2000', ''),
(4842, 2, '', '', ''),
(4843, 1, '', 'Всероссийский конкурс «Пэт-бутылка-блеск России» 2000', ''),
(4843, 2, '', '', ''),
(4844, 1, '', 'Пивная ярмарка Сибири 2000', ''),
(4844, 2, '', '', ''),
(4845, 1, '', 'Выставка «Омскпродопт-2000»', ''),
(4845, 2, '', '', ''),
(4846, 1, '', 'Агропромышленная ассамблея «Агропродсельмаш-2000»', ''),
(4846, 2, '', '', ''),
(4847, 1, '', 'Международный дегустационный конкурс «Интердринк» 2000', ''),
(4847, 2, '', '', ''),
(4848, 1, '', 'Международная специализированная выставка «Санкт-Петергбурский пивной аукцион» 2000', ''),
(4848, 2, '', '', ''),
(4849, 1, '', 'Конкурс «Сибирские Афины» 2000', ''),
(4849, 2, '', '', ''),
(4850, 1, '', 'Конкурс «Сибирские Афины» 2000', ''),
(4850, 2, '', '', ''),
(4851, 1, '', 'Межрегиональная универсальная ярмарка «Югорская ярмарка» 2001', ''),
(4851, 2, '', '', ''),
(4852, 1, '', 'Пивная ярмарка Сибири 2001', ''),
(4852, 2, '', '', ''),
(4853, 1, '', 'Агропромышленная ассамблея выставка «Агропродсельмаш» 2001', ''),
(4853, 2, '', '', ''),
(4854, 1, '', 'Выставка «Ярмарка вин и напитков» 2002', ''),
(4854, 2, '', '', ''),
(4855, 1, '', 'Межрегиональный конкурс «Лучшие товары Сибири - Гемма» 2002', ''),
(4855, 2, '', '', ''),
(4856, 1, '', 'Межрегиональный конкурс «Лучшие товары Сибири - Гемма» 2002', ''),
(4856, 2, '', '', ''),
(4857, 1, '', 'Пивная ярмарка Сибири 2002', ''),
(4857, 2, '', '', ''),
(4858, 1, '', 'Кузбасская ярмарка 2002', ''),
(4858, 2, '', '', ''),
(4859, 1, '', 'Конкурс «Сибирские Афины» 2002', ''),
(4859, 2, '', '', ''),
(4860, 1, '', 'Диплом Алтайско-торговой промышленной палаты 2002', ''),
(4860, 2, '', '', ''),
(4861, 1, '', 'Выставка «Продмаш. Агро-2003»', ''),
(4861, 2, '', '', ''),
(4862, 1, '', 'Межрегиональная специализированная выставка «Продмаркет» 2003', ''),
(4862, 2, '', '', ''),
(4863, 1, '', 'Пивная ярмарка Сибири 2003', ''),
(4863, 2, '', '', ''),
(4864, 1, '', 'Кузбасская ярмарка Сибири 2003', ''),
(4864, 2, '', '', ''),
(4865, 1, '', 'Пивная ярмарка Сибири 2004', ''),
(4865, 2, '', '', ''),
(4866, 1, '', 'Пивная ярмарка Сибири 2004', ''),
(4866, 2, '', '', ''),
(4867, 1, '', 'Пивная ярмарка Сибири 2004', ''),
(4867, 2, '', '', ''),
(4868, 1, '', 'Пивная ярмарка Сибири 2005', ''),
(4868, 2, '', '', ''),
(4869, 1, '', 'Пивная ярмарка Сибири 2005', ''),
(4869, 2, '', '', ''),
(4870, 1, '', 'Пивная ярмарка Сибири 2005', ''),
(4870, 2, '', '', ''),
(4871, 1, '', 'Международный профессиональный конкурс минеральных вод 2006', ''),
(4871, 2, '', '', ''),
(4872, 1, '', 'Международный форум «Живая вода России» 2007', ''),
(4872, 2, '', '', ''),
(4873, 1, '', 'Международный конкурс «Лучший продукт-2007»', ''),
(4873, 2, '', '', ''),
(4874, 1, '', 'Международный профессиональный конкурс минеральных вод 2007', ''),
(4874, 2, '', '', ''),
(4875, 1, '', 'Казахстанская международная выставка «Пищевая промышленность» 2011', ''),
(4875, 2, '', '', ''),
(4876, 1, '', 'Центрально-Азиатская международная выставка «Пищевая промышленность» 2011', ''),
(4876, 2, '', '', ''),
(4877, 1, '', 'Международный конкурс «Лучший продукт» 2011', ''),
(4877, 2, '', '', ''),
(4878, 1, '', '1997 Медаль Интерэкспо', ''),
(4878, 2, '', '', ''),
(4879, 1, '', '1997 Медаль Пивоиндустрия', ''),
(4879, 2, '', '', ''),
(4880, 1, '', '1998 Каир Медаль', ''),
(4880, 2, '', '', ''),
(4881, 1, '', '1998 Медаль ЛенЭкспо', ''),
(4881, 2, '', '', ''),
(4882, 1, '', '1998 Медаль Пивоиндустрия', ''),
(4882, 2, '', '', ''),
(4883, 1, '', '1998 Медаль Интерэкспо', ''),
(4883, 2, '', '', ''),
(4884, 1, '', '1998 Париж Медаль', ''),
(4884, 2, '', '', ''),
(4885, 1, '', '1998 Интерэкспо Медаль', ''),
(4885, 2, '', '', ''),
(4886, 1, '', '1998 Париж Медаль', ''),
(4886, 2, '', '', ''),
(4887, 1, '', '1999 Медаль Пивоиндустрия', ''),
(4887, 2, '', '', ''),
(4888, 1, '', '2000 Медаль Напитки России', ''),
(4888, 2, '', '', ''),
(4889, 1, '', '2000 Медаль Мускат', ''),
(4889, 2, '', '', ''),
(4890, 1, '', '2000 Пэт-бутылка-блеск', ''),
(4890, 2, '', '', ''),
(4891, 1, '', '2002 медаль Гемма', ''),
(4891, 2, '', '', ''),
(4892, 1, '', '2003 Медаль Продмаркет', ''),
(4892, 2, '', '', ''),
(4893, 1, '', '2003 Медаль Кузбасская ярмарка', ''),
(4893, 2, '', '', ''),
(4894, 1, '', '2007 Медаль Продэкспо', ''),
(4894, 2, '', '', ''),
(4895, 1, '', '2007 Медаль Живая вода России', ''),
(4895, 2, '', '', ''),
(4896, 1, '', '2011 медаль Продэкспо', ''),
(4896, 2, '', '', ''),
(4897, 1, '', '2011 медаль Продэкспо', ''),
(4897, 2, '', '', ''),
(4898, 1, '', '2011 Медаль Конкурс пива', ''),
(4898, 2, '', '', ''),
(4899, 1, '', '2011 медаль Продэкспо', ''),
(4899, 2, '', '', ''),
(4900, 1, '', '2011 медаль Продэкспо', ''),
(4900, 2, '', '', ''),
(4901, 1, '', '2011 медаль Продэкспо', ''),
(4901, 2, '', '', ''),
(4902, 1, '', '2011 Медаль Интерфуд', ''),
(4902, 2, '', '', ''),
(4908, 1, '', '2011 Медаль Интерфуд', ''),
(4908, 2, '', '', ''),
(4909, 1, '', '2011 Медаль Интерфуд', ''),
(4909, 2, '', '', ''),
(4910, 1, '', '2011 Медаль Продэкспо', ''),
(4910, 2, '', '', ''),
(4911, 1, '', '2011 Медаль Интерфуд', ''),
(4911, 2, '', '', ''),
(4912, 1, '', '2011 Медаль Интерфуд', ''),
(4912, 2, '', '', ''),
(4913, 1, '', '2011 Медаль Интерфуд', ''),
(4913, 2, '', '', ''),
(4914, 1, '', '2011 Медаль Интерфуд', ''),
(4914, 2, '', '', ''),
(4915, 1, '', 'Медаль Кузнецкая ярмарка', ''),
(4915, 2, '', '', ''),
(4916, 1, '', 'Медаль Лучший безалкагольный напиток', ''),
(4916, 2, '', '', ''),
(4917, 1, '', 'Медаль Лучший безалкагольный напиток', ''),
(4917, 2, '', '', ''),
(4918, 1, '', 'Медаль Интерэкспо', ''),
(4918, 2, '', '', ''),
(4919, 1, '', 'Медаль Сибирская ярмарка', ''),
(4919, 2, '', '', ''),
(4920, 1, '', 'Медаль Сибирская ярмарка', ''),
(4920, 2, '', '', ''),
(4921, 1, '', 'Медаль Сибирская ярмарка', ''),
(4921, 2, '', '', ''),
(4922, 1, '', 'Медаль Сибирская ярмарка', ''),
(4922, 2, '', '', ''),
(4983, 1, '', '', ''),
(4982, 1, '', '', ''),
(4946, 1, '', '', ''),
(4946, 2, '', '', ''),
(4947, 1, '', '', ''),
(4947, 2, '', '', ''),
(4948, 1, '', '', ''),
(4948, 2, '', '', ''),
(4949, 1, '', '', ''),
(4949, 2, '', '', ''),
(4950, 1, '', '', ''),
(4950, 2, '', '', ''),
(4951, 1, '', '', ''),
(4951, 2, '', '', ''),
(4952, 1, '', '', ''),
(4952, 2, '', '', ''),
(4953, 1, '', '', ''),
(4953, 2, '', '', ''),
(4954, 1, '', '', ''),
(4954, 2, '', '', ''),
(4955, 1, '', '', ''),
(4955, 2, '', '', ''),
(4956, 1, '', '', ''),
(4956, 2, '', '', ''),
(4957, 1, '', '', ''),
(4957, 2, '', '', ''),
(4958, 1, '', '', ''),
(4958, 2, '', '', ''),
(4959, 1, '', '', ''),
(4959, 2, '', '', ''),
(4961, 2, '', '', ''),
(4962, 1, '', '', ''),
(4962, 2, '', '', ''),
(4963, 1, '', '', ''),
(4963, 2, '', '', ''),
(4964, 1, '', '', ''),
(4964, 2, '', '', ''),
(4971, 1, '', '', ''),
(4972, 1, '', '', ''),
(4973, 1, '', '', ''),
(5044, 1, '', '', ''),
(5001, 1, '1 лицензия', '1 лицензия', ''),
(5002, 1, '2 лицензия', '2 лицензия', ''),
(5003, 1, '3 лицензия', '3 лицензия', ''),
(5004, 1, '4 лицензия', '4 лицензия', ''),
(5005, 1, '5 лицензия', '5 лицензия', ''),
(5006, 1, '6 лицензия', '6 лицензия', ''),
(5045, 1, '', '', ''),
(5371, 1, '/actions/vesennyaya-rasprodazha-elektrodov', '', ''),
(5366, 1, '', '', ''),
(5367, 1, '', '', ''),
(5368, 1, '', '', ''),
(5369, 1, '', '', ''),
(5370, 1, '', '', ''),
(5372, 1, '/actions/skidka-20-na-ves-assortiment-k-dnyu-stroitelya', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `infoblock`
--

CREATE TABLE IF NOT EXISTS `infoblock` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL,
  `weight` int(5) DEFAULT NULL,
  `type` int(1) NOT NULL DEFAULT '1',
  `url` varchar(255) NOT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Дамп данных таблицы `infoblock`
--

INSERT INTO `infoblock` (`id`, `date`, `weight`, `type`, `url`, `status`) VALUES
(28, '', 2, 3, 'front_info2', 1),
(32, '', 0, 3, 'footer_info1', 1),
(33, '', 0, 3, 'front_perfect1', 1),
(34, '', 0, 3, 'front_perfect2', 1),
(35, '', 0, 3, 'front_perfect3', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `content_id` int(10) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `name` text,
  `url` varchar(255) DEFAULT NULL,
  `icon` varchar(255) NOT NULL,
  `dictionary_id` int(5) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=182 ;

--
-- Дамп данных таблицы `menu`
--

INSERT INTO `menu` (`id`, `content_id`, `module`, `parent_id`, `name`, `url`, `icon`, `dictionary_id`, `weight`, `status`) VALUES
(170, 0, '0', 0, NULL, '/contacts', '', 1, 5, 1),
(169, 0, '0', 0, NULL, '/about', '', 1, 4, 1),
(181, 0, '0', 0, NULL, '/actions', '', 1, 3, 1),
(180, 0, '0', 0, NULL, '/catalog', '', 1, 2, 1),
(179, 0, '0', 0, NULL, '/', '', 1, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modulinfo`
--

CREATE TABLE IF NOT EXISTS `modulinfo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Дамп данных таблицы `modulinfo`
--

INSERT INTO `modulinfo` (`id`, `module`) VALUES
(14, 'reviews'),
(15, 'documents'),
(16, 'news'),
(17, 'articles');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `date` varchar(64) DEFAULT NULL,
  `timestamp` int(20) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `type` int(1) NOT NULL DEFAULT '0',
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=92 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `date`, `timestamp`, `alias`, `weight`, `type`, `status`) VALUES
(90, '2016-05-05', 1463517876, 'amurskogo-gosudarstvennogo-universiteta', 0, 0, 1),
(91, '2016-05-14', 1463517948, 'predpolagaetsya-rabota-lektoriya', 0, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `alias` varchar(250) CHARACTER SET utf8 NOT NULL,
  `weight` int(5) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `in_front` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=28 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `alias`, `weight`, `status`, `in_front`) VALUES
(3, 'contacts', 0, 1, 0),
(15, 'about', 0, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `parking`
--

CREATE TABLE IF NOT EXISTS `parking` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pos_x` int(5) DEFAULT NULL,
  `pos_y` int(5) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `partners`
--

CREATE TABLE IF NOT EXISTS `partners` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `alias` varchar(250) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL,
  `map_x` varchar(250) DEFAULT NULL,
  `map_y` varchar(250) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `alias` varchar(250) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Структура таблицы `poll`
--

CREATE TABLE IF NOT EXISTS `poll` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `lang_id` int(3) NOT NULL DEFAULT '1',
  `news_id` int(5) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Дамп данных таблицы `poll`
--

INSERT INTO `poll` (`id`, `lang_id`, `news_id`, `result`, `ip`) VALUES
(1, 1, 3, 'Ассоль', ''),
(2, 1, 3, 'Фассоль', ''),
(3, 1, 3, 'Массоль', ''),
(4, 1, 3, 'Ассоль', ''),
(5, 1, 3, 'Ассоль', ''),
(6, 1, 3, 'Ассоль', ''),
(7, 1, 3, 'Ассоль', ''),
(8, 1, 3, 'Массоль', ''),
(9, 1, 3, 'Фассоль', ''),
(10, 1, 3, 'Фассоль', ''),
(11, 1, 3, 'Массоль', ''),
(12, 1, 3, 'Ассоль', ''),
(13, 1, 3, 'Массоль', ''),
(14, 1, 3, 'Массоль', ''),
(15, 1, 3, 'Ассоль', ''),
(16, 1, 3, 'Холодный чай', ''),
(17, 1, 3, 'Морс', ''),
(18, 1, 3, 'Морс', ''),
(19, 1, 3, 'Компот', ''),
(20, 1, 3, 'Компот', ''),
(21, 1, 3, 'Компот', ''),
(22, 1, 3, 'Морс', ''),
(23, 1, 3, 'Холодный чай', ''),
(24, 1, 3, 'Морс', ''),
(25, 1, 3, 'Компот', ''),
(26, 1, 3, 'Морс', ''),
(27, 1, 3, 'Морс', ''),
(28, 1, 3, 'Холодный чай', ''),
(29, 1, 3, 'Морс', ''),
(30, 1, 3, 'Морс', ''),
(31, 1, 3, 'Компот', ''),
(32, 1, 3, 'Компот', ''),
(33, 1, 3, 'Компот', ''),
(34, 1, 3, 'Компот', '');

-- --------------------------------------------------------

--
-- Структура таблицы `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `alias` varchar(250) DEFAULT NULL,
  `is_fine` int(1) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `parent_id` int(5) DEFAULT NULL,
  `group_id` int(3) DEFAULT NULL,
  `date` varchar(64) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

CREATE TABLE IF NOT EXISTS `seo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `lang_id` int(10) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `meta_k` text,
  `meta_d` text,
  `alt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2161 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `lang_id`, `title`, `meta_k`, `meta_d`, `alt`) VALUES
(728, 1, 'Цены на пластиковые окна в Новосибирске', 'цена стоимость пластиковых окон в Новосибирске', 'Фиксированные низкие цены на стандартное остекление окон ПВХ профилем в Новосибирске и Бердске. Выгодное предложение от производителя!', ''),
(727, 1, 'Монтаж, установка пластиковых окон в Новосибирске', 'монтаж установка пластиковых окон', 'Установка пластиковых окон в Новосибирске и Бердске в кратчайшие сроки и по выгодным ценам. Все работы проводит производитель ПВХ - конструкций ЭлитМонтаж.', ''),
(495, 1, 'Отделка балконов и лоджий в Новосибирске', 'Отделка, обшивка балконов и лоджий в Новосибирске', 'Отделка, обшивка балконов и лоджий в Новосибирске под ключ и частично - выбор услуг за вами. Широкий выбор отделочных материалов. ', ''),
(498, 1, 'Мебель для балкона и лоджии, встроенные шкафы, шкафы-купе для балкона', 'Мебель для балкона и лоджии, встроенные шкафы, шкафы-купе для балкона, полки и антресоли', 'Мебель для балкона и лоджии, встроенные шкафы, шкафы-купе для балкона, полки и антресоли на заказ - заказы любой сложности, широкий выбор материалов. ', ''),
(529, 1, 'Монтаж пластиковых стеновых панелей в Новосибирске', 'монтаж пластиковых стеновых панелей', 'Монтаж пластиковых стеновых панелей на балконе, лоджии, ванной комнате.', ''),
(2146, 1, '', '', '', ''),
(711, 1, 'Монтаж сайдинга в Новосибирске', 'Монтаж сайдинга, обшивка домов и балконов сайдингом', 'Монтаж сайдинга в Новосибирске - обшивка домов, балконов и лоджий. ', ''),
(505, 1, 'Ремонт, регулировка, отделка входных групп и пластиковых дверей', 'Ремонт, регулировка, отделка входных групп и пластиковых дверей', 'Ремонт, регулировка, отделка входных групп и пластиковых дверей от компании Элитмонтаж.', ''),
(497, 1, 'Ремонт лоджии, козырька балкона, комплектующие, обустройство и тонировка балконов и лоджий', 'Ремонт лоджии, козырька балкона, комплектующие, обустройство и тонировка балконов и лоджий', 'Ремонт лоджии, козырька балкона, установка порогов, перил, москитных сеток, замена комплектующих, обустройство и тонировка балконов и лоджий.', ''),
(496, 1, 'Утепление балконов и лоджий в Новосибирске', 'утепление балконов и лоджий в Новосибирске', 'Утепление балконов и лоджий в Новосибирске минеральной ватой, пеноплексом и пенофолом с последующей отделкой. Вынос лоджии в комнату. ', ''),
(738, 1, 'Отделка окон в Новосибирске, установка откосов, подоконников, уголков, москитных сеток, отделка холодильника под окном', 'отделка окон, установка откосов, подоконников, отливов, уголков, отделка холодильника под окном', 'Наружная и внутренняя отделка окон в Новосибирске: установка откосов, уголков, подоконников, москитных сеток; отделка холодильника под окном. ', ''),
(739, 1, 'Ремонт и регулировка пластиковых окон в Новосибирске', 'Ремонт и регулировка пластиковых окон в Новосибирске, замена стеклопакетов, установка детских замков', 'Ремонт и регулировка пластиковых окон в Новосибирске: замена стеклопакетов, фурнитуры, регулировка окон и пластиковых дверей, установка детских замков на раму. ', ''),
(715, 1, 'Остекление балконов и лоджий в Новосибирске', 'Остекление балконов и лоджий в Новосибирске, застеклить балкон лоджию', 'Производитель ПВХ и алюминиевых конструкций компания ЭлитМонтаж проводит качественное остекление балконов и лоджий в Новосибирске и Бердске. ', ''),
(557, 1, 'Цены на остекление балконов и лоджий в Новосибирске', 'Цены на остекление балконов и лоджий в Новосибирске, стоимость остекления лоджий и балконов', 'Фиксированные цены на стандартное пластиковое и алюминиевое остекление балконов и лоджий в Новосибирске от компании-производителя ЭлитМонтаж. ', ''),
(639, 1, 'Изготовление пластиковых окон, входных групп, ПВХ и алюминиевых конструкций в Новосибирске', 'Изготовление пластиковых окон, входных групп, ПВХ и алюминиевых конструкций в Новосибирске', 'Изготовление пластиковых окон, входных групп, ПВХ и алюминиевых конструкций в Новосибирске - производство ЭлитМонтаж. ', ''),
(504, 1, 'Пластиковые входные двери и входные группы', 'Пластиковые входные двери, входные группы', 'Входные группы и пластиковые входные двери от производителя в Новосибирске на заказ. Принимаем заказы любой сложности. Предлагаем последующую отделку.', ''),
(527, 1, 'Отделка балконов и лоджий евровагонкой в Новосибирске', 'обшить балкон лоджию евровагонкой', 'Отделка балконов, лоджий и других помещений евровагонкой недорого и качественно. ', ''),
(1775, 1, '', '', '', ''),
(2148, 1, '', '', '', ''),
(642, 1, 'Остекление веранд, теплиц, беседок в Новосибирске', 'Остекление веранд, теплиц, беседок', 'Остекление веранд, теплиц, беседок по индивидуальному заказу пвх профилем.', ''),
(2160, 1, '', '', '', ''),
(2159, 1, '', '', '', ''),
(1705, 1, '', '', '', ''),
(1738, 1, '', '', '', ''),
(1750, 1, '', '', '', ''),
(1751, 1, '', '', '', ''),
(1752, 1, '', '', '', ''),
(1753, 1, '', '', '', ''),
(1754, 1, '', '', '', ''),
(1755, 1, '', '', '', ''),
(1757, 1, '', '', '', ''),
(1758, 1, '', '', '', ''),
(1760, 1, '', '', '', ''),
(1761, 1, '', '', '', ''),
(2088, 1, '', '', '', ''),
(2150, 1, '', '', '', ''),
(2149, 1, '', '', '', ''),
(2151, 1, '', '', '', ''),
(2152, 1, '', '', '', ''),
(2153, 1, '', '', '', ''),
(2154, 1, '', '', '', ''),
(2155, 1, '', '', '', ''),
(2156, 1, '', '', '', ''),
(2157, 1, '', '', '', ''),
(2158, 1, '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `alias` varchar(250) DEFAULT NULL,
  `is_fine` int(1) DEFAULT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Структура таблицы `siteinfo`
--

CREATE TABLE IF NOT EXISTS `siteinfo` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(64) CHARACTER SET utf8 NOT NULL,
  `email1` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email2` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email3` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email4` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email5` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email6` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email7` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email8` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email9` varchar(32) CHARACTER SET utf8 NOT NULL,
  `email10` varchar(32) CHARACTER SET utf8 NOT NULL,
  `tell` varchar(64) CHARACTER SET utf8 NOT NULL,
  `counter` text CHARACTER SET utf8 NOT NULL,
  `map` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `siteinfo`
--

INSERT INTO `siteinfo` (`id`, `email`, `email1`, `email2`, `email3`, `email4`, `email5`, `email6`, `email7`, `email8`, `email9`, `email10`, `tell`, `counter`, `map`) VALUES
(1, 'dmvolt77@yandex.ru', '', '', '', '', '', '', '', '', '', '', '+7 (383) 51-43-00', '', '<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=byFdb_iYRns3Wtd4F-LooKRkoaJ4PcRs&width=100%&height=100%&lang=ru_RU&sourceType=constructor&scroll=true"></script>');

-- --------------------------------------------------------

--
-- Структура таблицы `specials`
--

CREATE TABLE IF NOT EXISTS `specials` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `alias` varchar(250) DEFAULT NULL,
  `date` varchar(255) NOT NULL,
  `weight` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `avatar` varchar(250) NOT NULL DEFAULT '0',
  `email` varchar(254) NOT NULL,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL,
  `rempass` varchar(255) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(10) unsigned DEFAULT NULL,
  `role_id` int(3) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `avatar`, `email`, `username`, `password`, `rempass`, `logins`, `last_login`, `role_id`, `status`) VALUES
(6, '0', 'dmvolt77@gmail.com', 'dmvolt77', 'ad1a290759b4e91c0bb575b70b900b9c', '', 0, NULL, 0, 1),
(7, '0', 'admin@test.test', 'admin', 'fedb9c660af1c8fe7ddd6ec7fac25ebf', '', 0, NULL, 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
